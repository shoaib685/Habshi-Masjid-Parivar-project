import { i as __toESM } from "../_runtime.mjs";
import { t as HttpsProxyAgent } from "./https-proxy-agent+[...].mjs";
import { t as require_asn1 } from "./asn1.js+[...].mjs";
import { t as require_jws } from "./jws.mjs";
import { t as require_ece } from "./http_ece.mjs";
import nodeHTTPS from "node:https";
import crypto from "node:crypto";
import { URL as URL$1 } from "node:url";
//#region node_modules/.pnpm/web-push@4.0.0/node_modules/web-push/src/web-push-error.js
var WebPushError = class extends Error {
	constructor(message, statusCode, headers, body, endpoint) {
		super(message);
		this.name = "WebPushError";
		this.statusCode = statusCode;
		this.headers = headers;
		this.body = body;
		this.endpoint = endpoint;
	}
};
//#endregion
//#region node_modules/.pnpm/web-push@4.0.0/node_modules/web-push/src/web-push-constants.js
var import_asn1 = /* @__PURE__ */ __toESM(require_asn1(), 1);
var import_jws = /* @__PURE__ */ __toESM(require_jws(), 1);
var supportedContentEncodings = {
	AES_GCM: "aesgcm",
	AES_128_GCM: "aes128gcm"
};
var supportedUrgency = {
	VERY_LOW: "very-low",
	LOW: "low",
	NORMAL: "normal",
	HIGH: "high"
};
//#endregion
//#region node_modules/.pnpm/web-push@4.0.0/node_modules/web-push/src/urlsafe-base64-helper.js
/**
* @param {string} base64
* @returns {boolean}
*/
function validate(base64) {
	return /^[A-Za-z0-9\-_]+$/.test(base64);
}
//#endregion
//#region node_modules/.pnpm/web-push@4.0.0/node_modules/web-push/src/vapid-helper.js
/**
* DEFAULT_EXPIRATION is set to seconds in 12 hours
*/
var DEFAULT_EXPIRATION_SECONDS = 720 * 60;
var MAX_EXPIRATION_SECONDS = 1440 * 60;
var ECPrivateKeyASN = import_asn1.default.define("ECPrivateKey", function() {
	this.seq().obj(this.key("version").int(), this.key("privateKey").octstr(), this.key("parameters").explicit(0).objid().optional(), this.key("publicKey").explicit(1).bitstr().optional());
});
function toPEM(key) {
	return ECPrivateKeyASN.encode({
		version: 1,
		privateKey: key,
		parameters: [
			1,
			2,
			840,
			10045,
			3,
			1,
			7
		]
	}, "pem", { label: "EC PRIVATE KEY" });
}
function validateSubject(subject) {
	if (!subject) throw new Error("No subject set in vapidDetails.subject.");
	if (typeof subject !== "string" || subject.length === 0) throw new Error("The subject value must be a string containing an https: URL or mailto: address. " + subject);
	let subjectParseResult;
	try {
		subjectParseResult = new URL$1(subject);
	} catch (err) {
		throw new Error("Vapid subject is not a valid URL. " + subject, { cause: err });
	}
	if (!["https:", "mailto:"].includes(subjectParseResult.protocol)) throw new Error("Vapid subject is not an https: or mailto: URL. " + subject);
	if (subjectParseResult.hostname === "localhost") console.warn("Vapid subject points to a localhost web URI, which is unsupported by Apple's push notification server and will result in a BadJwtToken error when sending notifications.");
}
function validatePublicKey(publicKey) {
	if (!publicKey) throw new Error("No key set vapidDetails.publicKey");
	if (typeof publicKey !== "string") throw new Error("Vapid public key is must be a URL safe Base 64 encoded string.");
	if (!validate(publicKey)) throw new Error("Vapid public key must be a URL safe Base 64 (without \"=\")");
	publicKey = Buffer.from(publicKey, "base64url");
	if (publicKey.length !== 65) throw new Error("Vapid public key should be 65 bytes long when decoded.");
}
function validatePrivateKey(privateKey) {
	if (!privateKey) throw new Error("No key set in vapidDetails.privateKey");
	if (typeof privateKey !== "string") throw new Error("Vapid private key must be a URL safe Base 64 encoded string.");
	if (!validate(privateKey)) throw new Error("Vapid private key must be a URL safe Base 64 (without \"=\")");
	privateKey = Buffer.from(privateKey, "base64url");
	if (privateKey.length !== 32) throw new Error("Vapid private key should be 32 bytes long when decoded.");
}
/**
* Given the number of seconds calculates
* the expiration in the future by adding the passed `numSeconds`
* with the current seconds from Unix Epoch
*
* @param {Number} numSeconds Number of seconds to be added
* @return {Number} Future expiration in seconds
*/
function getFutureExpirationTimestamp(numSeconds) {
	const futureExp = /* @__PURE__ */ new Date();
	futureExp.setSeconds(futureExp.getSeconds() + numSeconds);
	return Math.floor(futureExp.getTime() / 1e3);
}
/**
* Validates the Expiration Header based on the VAPID Spec
* Throws error of type `Error` if the expiration is not validated
*
* @param {Number} expiration Expiration seconds from Epoch to be validated
*/
function validateExpiration(expiration) {
	if (!Number.isInteger(expiration)) throw new Error("`expiration` value must be a number");
	if (expiration < 0) throw new Error("`expiration` must be a positive integer");
	if (expiration >= getFutureExpirationTimestamp(MAX_EXPIRATION_SECONDS)) throw new Error("`expiration` value is greater than maximum of 24 hours");
}
/**
* This method takes the required VAPID parameters and returns the required
* header to be added to a Web Push Protocol Request.
* @param  {string} audience        This must be the origin of the push service.
* @param  {string} subject         This should be a URL or a 'mailto:' email
* address.
* @param  {string} publicKey       The VAPID public key.
* @param  {string} privateKey      The VAPID private key.
* @param  {string} contentEncoding The contentEncoding type.
* @param  {integer} [expiration]   The expiration of the VAPID JWT.
* @return {Object}                 Returns an Object with the Authorization and
* 'Crypto-Key' values to be used as headers.
*/
function getVapidHeaders(audience, subject, publicKey, privateKey, contentEncoding, expiration) {
	if (!audience) throw new Error("No audience could be generated for VAPID.");
	if (typeof audience !== "string" || audience.length === 0) throw new Error("The audience value must be a string containing the origin of a push service. " + audience);
	try {
		new URL$1(audience);
	} catch (err) {
		throw new Error("VAPID audience is not a url. " + audience, { cause: err });
	}
	validateSubject(subject);
	validatePublicKey(publicKey);
	validatePrivateKey(privateKey);
	privateKey = Buffer.from(privateKey, "base64url");
	if (expiration) validateExpiration(expiration);
	else expiration = getFutureExpirationTimestamp(DEFAULT_EXPIRATION_SECONDS);
	const header = {
		typ: "JWT",
		alg: "ES256"
	};
	const jwtPayload = {
		aud: audience,
		exp: expiration,
		sub: subject
	};
	const jwt = import_jws.sign({
		header,
		payload: jwtPayload,
		privateKey: toPEM(privateKey)
	});
	if (contentEncoding === supportedContentEncodings.AES_128_GCM) return { Authorization: "vapid t=" + jwt + ", k=" + publicKey };
	if (contentEncoding === supportedContentEncodings.AES_GCM) return {
		Authorization: "WebPush " + jwt,
		"Crypto-Key": "p256ecdsa=" + publicKey
	};
	throw new Error("Unsupported encoding type specified.");
}
//#endregion
//#region node_modules/.pnpm/web-push@4.0.0/node_modules/web-push/src/encryption-helper.js
var import_ece = /* @__PURE__ */ __toESM(require_ece(), 1);
function encrypt(userPublicKey, userAuth, payload, contentEncoding) {
	if (!userPublicKey) throw new Error("No user public key provided for encryption.");
	if (typeof userPublicKey !== "string") throw new Error("The subscription p256dh value must be a string.");
	if (Buffer.from(userPublicKey, "base64url").length !== 65) throw new Error("The subscription p256dh value should be 65 bytes long.");
	if (!userAuth) throw new Error("No user auth provided for encryption.");
	if (typeof userAuth !== "string") throw new Error("The subscription auth key must be a string.");
	if (Buffer.from(userAuth, "base64url").length < 16) throw new Error("The subscription auth key should be at least 16 bytes long");
	if (typeof payload !== "string" && !Buffer.isBuffer(payload)) throw new Error("Payload must be either a string or a Node Buffer.");
	if (typeof payload === "string" || payload instanceof String) payload = Buffer.from(payload);
	const localCurve = crypto.createECDH("prime256v1");
	const localPublicKey = localCurve.generateKeys();
	const salt = crypto.randomBytes(16).toString("base64url");
	return {
		localPublicKey,
		salt,
		cipherText: import_ece.default.encrypt(payload, {
			version: contentEncoding,
			dh: userPublicKey,
			privateKey: localCurve,
			salt,
			authSecret: userAuth
		})
	};
}
//#endregion
//#region node_modules/.pnpm/web-push@4.0.0/node_modules/web-push/src/web-push-lib.js
var DEFAULT_TTL = 2419200;
var gcmAPIKey = "";
var vapidDetails;
var WebPushLib = class {
	/**
	* When sending messages to a GCM endpoint you need to set the GCM API key
	* by either calling setGMAPIKey() or passing in the API key as an option
	* to sendNotification().
	* @param  {string} apiKey The API key to send with the GCM request.
	*/
	setGCMAPIKey(apiKey) {
		if (apiKey === null) {
			gcmAPIKey = null;
			return;
		}
		if (typeof apiKey === "undefined" || typeof apiKey !== "string" || apiKey.length === 0) throw new Error("The GCM API Key should be a non-empty string or null.");
		gcmAPIKey = apiKey;
	}
	/**
	* When making requests where you want to define VAPID details, call this
	* method before sendNotification() or pass in the details and options to
	* sendNotification.
	* @param  {string} subject    This must be either a URL or a 'mailto:'
	* address. For example: 'https://my-site.com/contact' or
	* 'mailto: contact@my-site.com'
	* @param  {string} publicKey  The public VAPID key, a URL safe, base64 encoded string
	* @param  {string} privateKey The private VAPID key, a URL safe, base64 encoded string.
	*/
	setVapidDetails(subject, publicKey, privateKey) {
		if (arguments.length === 1 && arguments[0] === null) {
			vapidDetails = null;
			return;
		}
		validateSubject(subject);
		validatePublicKey(publicKey);
		validatePrivateKey(privateKey);
		vapidDetails = {
			subject,
			publicKey,
			privateKey
		};
	}
	/**
	* To get the details of a request to trigger a push message, without sending
	* a push notification call this method.
	*
	* This method will throw an error if there is an issue with the input.
	* @param  {PushSubscription} subscription The PushSubscription you wish to
	* send the notification to.
	* @param  {string|Buffer} [payload]       The payload you wish to send to the
	* the user.
	* @param  {Object} [options]              Options for the GCM API key and
	* vapid keys can be passed in if they are unique for each notification you
	* wish to send.
	* @return {Object}                       This method returns an Object which
	* contains 'endpoint', 'method', 'headers' and 'payload'.
	*/
	generateRequestDetails(subscription, payload, options) {
		if (!subscription || !subscription.endpoint) throw new Error("You must pass in a subscription with at least an endpoint.");
		if (typeof subscription.endpoint !== "string" || subscription.endpoint.length === 0) throw new Error("The subscription endpoint must be a string with a valid URL.");
		if (payload) {
			if (typeof subscription !== "object" || !subscription.keys || !subscription.keys.p256dh || !subscription.keys.auth) throw new Error("To send a message with a payload, the subscription must have 'auth' and 'p256dh' keys.");
		}
		let currentGCMAPIKey = gcmAPIKey;
		let currentVapidDetails = vapidDetails;
		let timeToLive = DEFAULT_TTL;
		let extraHeaders = {};
		let contentEncoding = supportedContentEncodings.AES_128_GCM;
		let urgency = supportedUrgency.NORMAL;
		let topic;
		let proxy;
		let agent;
		let timeout;
		if (options) {
			const validOptionKeys = [
				"headers",
				"gcmAPIKey",
				"vapidDetails",
				"TTL",
				"contentEncoding",
				"urgency",
				"topic",
				"proxy",
				"agent",
				"timeout"
			];
			const optionKeys = Object.keys(options);
			for (let i = 0; i < optionKeys.length; i += 1) {
				const optionKey = optionKeys[i];
				if (!validOptionKeys.includes(optionKey)) throw new Error("'" + optionKey + "' is an invalid option. The valid options are ['" + validOptionKeys.join("', '") + "'].");
			}
			if (options.headers) {
				extraHeaders = options.headers;
				let duplicates = Object.keys(extraHeaders).filter(function(header) {
					return typeof options[header] !== "undefined";
				});
				if (duplicates.length > 0) throw new Error("Duplicated headers defined [" + duplicates.join(",") + "]. Please either define the header in thetop level options OR in the 'headers' key.");
			}
			if (options.gcmAPIKey) currentGCMAPIKey = options.gcmAPIKey;
			if (options.vapidDetails !== void 0) currentVapidDetails = options.vapidDetails;
			if (options.TTL !== void 0) {
				timeToLive = Number(options.TTL);
				if (timeToLive < 0) throw new Error("TTL should be a number and should be at least 0");
			}
			if (options.contentEncoding) if (options.contentEncoding === supportedContentEncodings.AES_128_GCM || options.contentEncoding === supportedContentEncodings.AES_GCM) contentEncoding = options.contentEncoding;
			else throw new Error("Unsupported content encoding specified.");
			if (options.urgency) if (options.urgency === supportedUrgency.VERY_LOW || options.urgency === supportedUrgency.LOW || options.urgency === supportedUrgency.NORMAL || options.urgency === supportedUrgency.HIGH) urgency = options.urgency;
			else throw new Error("Unsupported urgency specified.");
			if (options.topic) {
				if (!validate(options.topic)) throw new Error("Unsupported characters set use the URL or filename-safe Base64 characters set");
				if (options.topic.length > 32) throw new Error("use maximum of 32 characters from the URL or filename-safe Base64 characters set");
				topic = options.topic;
			}
			if (options.proxy) if (typeof options.proxy === "string" || typeof options.proxy.host === "string") proxy = options.proxy;
			else console.warn("Attempt to use proxy option, but invalid type it should be a string or proxy options object.");
			if (options.agent) if (options.agent instanceof nodeHTTPS.Agent) {
				if (proxy) console.warn("Agent option will be ignored because proxy option is defined.");
				agent = options.agent;
			} else console.warn("Wrong type for the agent option, it should be an instance of https.Agent.");
			if (typeof options.timeout === "number") timeout = options.timeout;
		}
		if (typeof timeToLive === "undefined") timeToLive = DEFAULT_TTL;
		const requestDetails = {
			method: "POST",
			headers: { TTL: timeToLive }
		};
		Object.keys(extraHeaders).forEach(function(header) {
			requestDetails.headers[header] = extraHeaders[header];
		});
		let requestPayload = null;
		if (payload) {
			const encrypted = encrypt(subscription.keys.p256dh, subscription.keys.auth, payload, contentEncoding);
			requestDetails.headers["Content-Length"] = encrypted.cipherText.length;
			requestDetails.headers["Content-Type"] = "application/octet-stream";
			if (contentEncoding === supportedContentEncodings.AES_128_GCM) requestDetails.headers["Content-Encoding"] = supportedContentEncodings.AES_128_GCM;
			else if (contentEncoding === supportedContentEncodings.AES_GCM) {
				requestDetails.headers["Content-Encoding"] = supportedContentEncodings.AES_GCM;
				requestDetails.headers.Encryption = "salt=" + encrypted.salt;
				requestDetails.headers["Crypto-Key"] = "dh=" + encrypted.localPublicKey.toString("base64url");
			}
			requestPayload = encrypted.cipherText;
		} else requestDetails.headers["Content-Length"] = 0;
		const isGCM = subscription.endpoint.startsWith("https://android.googleapis.com/gcm/send");
		const isFCM = subscription.endpoint.startsWith("https://fcm.googleapis.com/fcm/send");
		if (isGCM) if (!currentGCMAPIKey) console.warn("Attempt to send push notification to GCM endpoint, but no GCM key is defined. Please use setGCMApiKey() or add 'gcmAPIKey' as an option.");
		else requestDetails.headers.Authorization = "key=" + currentGCMAPIKey;
		else if (currentVapidDetails) {
			const parsedUrl = new URL(subscription.endpoint);
			const vapidHeaders = getVapidHeaders(parsedUrl.protocol + "//" + parsedUrl.host, currentVapidDetails.subject, currentVapidDetails.publicKey, currentVapidDetails.privateKey, contentEncoding);
			requestDetails.headers.Authorization = vapidHeaders.Authorization;
			if (contentEncoding === supportedContentEncodings.AES_GCM) if (requestDetails.headers["Crypto-Key"]) requestDetails.headers["Crypto-Key"] += ";" + vapidHeaders["Crypto-Key"];
			else requestDetails.headers["Crypto-Key"] = vapidHeaders["Crypto-Key"];
		} else if (isFCM && currentGCMAPIKey) requestDetails.headers.Authorization = "key=" + currentGCMAPIKey;
		requestDetails.headers.Urgency = urgency;
		if (topic) requestDetails.headers.Topic = topic;
		requestDetails.body = requestPayload;
		requestDetails.endpoint = subscription.endpoint;
		if (proxy) requestDetails.proxy = proxy;
		if (agent) requestDetails.agent = agent;
		if (timeout) requestDetails.timeout = timeout;
		return requestDetails;
	}
	/**
	* To send a push notification call this method with a subscription, optional
	* payload and any options.
	* @param  {PushSubscription} subscription The PushSubscription you wish to
	* send the notification to.
	* @param  {string|Buffer} [payload]       The payload you wish to send to the
	* the user.
	* @param  {Object} [options]              Options for the GCM API key and
	* vapid keys can be passed in if they are unique for each notification you
	* wish to send.
	* @return {Promise}                       This method returns a Promise which
	* resolves if the sending of the notification was successful, otherwise it
	* rejects.
	*/
	sendNotification(subscription, payload, options) {
		let requestDetails;
		try {
			requestDetails = this.generateRequestDetails(subscription, payload, options);
		} catch (err) {
			return Promise.reject(err);
		}
		return new Promise(function(resolve, reject) {
			const httpsOptions = {};
			const urlParts = new URL(requestDetails.endpoint);
			httpsOptions.hostname = urlParts.hostname;
			httpsOptions.port = urlParts.port;
			httpsOptions.path = urlParts.pathname + urlParts.search;
			httpsOptions.headers = requestDetails.headers;
			httpsOptions.method = requestDetails.method;
			if (requestDetails.timeout) httpsOptions.timeout = requestDetails.timeout;
			if (requestDetails.agent) httpsOptions.agent = requestDetails.agent;
			if (requestDetails.proxy) httpsOptions.agent = new HttpsProxyAgent(requestDetails.proxy);
			const pushRequest = nodeHTTPS.request(httpsOptions, function(pushResponse) {
				let responseText = "";
				pushResponse.on("data", function(chunk) {
					responseText += chunk;
				});
				pushResponse.on("end", function() {
					if (pushResponse.statusCode < 200 || pushResponse.statusCode > 299) reject(new WebPushError("Received unexpected response code", pushResponse.statusCode, pushResponse.headers, responseText, requestDetails.endpoint));
					else resolve({
						statusCode: pushResponse.statusCode,
						body: responseText,
						headers: pushResponse.headers
					});
				});
			});
			if (requestDetails.timeout) pushRequest.on("timeout", function() {
				pushRequest.destroy(/* @__PURE__ */ new Error("Socket timeout"));
			});
			pushRequest.on("error", function(e) {
				reject(e);
			});
			if (requestDetails.body) pushRequest.write(requestDetails.body);
			pushRequest.end();
		});
	}
};
//#endregion
//#region node_modules/.pnpm/web-push@4.0.0/node_modules/web-push/src/index.js
var webPush = new WebPushLib();
webPush.setGCMAPIKey;
var setVapidDetails = webPush.setVapidDetails;
webPush.generateRequestDetails;
var sendNotification = webPush.sendNotification.bind(webPush);
//#endregion
export { setVapidDetails as n, sendNotification as t };

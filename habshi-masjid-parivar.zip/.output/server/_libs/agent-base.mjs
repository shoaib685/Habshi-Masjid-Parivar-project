import * as net from "net";
import * as http from "http";
import { Agent } from "https";
//#region node_modules/.pnpm/agent-base@9.0.0/node_modules/agent-base/dist/index.js
var INTERNAL = Symbol("AgentBaseInternalState");
var Agent$1 = class extends http.Agent {
	constructor(opts) {
		super(opts);
		this[INTERNAL] = {};
	}
	/**
	* Determine whether this is an `http` or `https` request.
	*/
	isSecureEndpoint(options) {
		if (options) {
			if (typeof options.secureEndpoint === "boolean") return options.secureEndpoint;
			if (typeof options.protocol === "string") return options.protocol === "https:";
		}
		const { stack } = /* @__PURE__ */ new Error();
		if (typeof stack !== "string") return false;
		return stack.split("\n").some((l) => l.indexOf("(https.js:") !== -1 || l.indexOf("node:https:") !== -1);
	}
	incrementSockets(name) {
		if (this.maxSockets === Infinity && this.maxTotalSockets === Infinity) return null;
		if (!this.sockets[name]) this.sockets[name] = [];
		const fakeSocket = new net.Socket({ writable: false });
		this.sockets[name].push(fakeSocket);
		this.totalSocketCount++;
		return fakeSocket;
	}
	decrementSockets(name, socket) {
		if (!this.sockets[name] || socket === null) return;
		const sockets = this.sockets[name];
		const index = sockets.indexOf(socket);
		if (index !== -1) {
			sockets.splice(index, 1);
			this.totalSocketCount--;
			if (sockets.length === 0) delete this.sockets[name];
		}
	}
	getName(options) {
		if (this.isSecureEndpoint(options)) return Agent.prototype.getName.call(this, options);
		return super.getName(options);
	}
	createSocket(req, options, cb) {
		const connectOpts = {
			...options,
			secureEndpoint: this.isSecureEndpoint(options)
		};
		const name = this.getName(connectOpts);
		const fakeSocket = this.incrementSockets(name);
		Promise.resolve().then(() => this.connect(req, connectOpts)).then((socket) => {
			this.decrementSockets(name, fakeSocket);
			if (typeof socket.addRequest === "function") try {
				return socket.addRequest(req, connectOpts);
			} catch (err) {
				return cb(err);
			}
			this[INTERNAL].currentSocket = socket;
			super.createSocket(req, options, cb);
		}, (err) => {
			this.decrementSockets(name, fakeSocket);
			cb(err);
		});
	}
	createConnection() {
		const socket = this[INTERNAL].currentSocket;
		this[INTERNAL].currentSocket = void 0;
		if (!socket) throw new Error("No socket was returned in the `connect()` function");
		return socket;
	}
	get defaultPort() {
		return this[INTERNAL].defaultPort ?? (this.protocol === "https:" ? 443 : 80);
	}
	set defaultPort(v) {
		if (this[INTERNAL]) this[INTERNAL].defaultPort = v;
	}
	get protocol() {
		return this[INTERNAL].protocol ?? (this.isSecureEndpoint() ? "https:" : "http:");
	}
	set protocol(v) {
		if (this[INTERNAL]) this[INTERNAL].protocol = v;
	}
};
//#endregion
export { Agent$1 as t };

import { i as __toESM } from "../_runtime.mjs";
import { t as require_src } from "./debug+[...].mjs";
import { t as Agent } from "./agent-base.mjs";
import * as net from "net";
import * as tls from "tls";
import assert from "assert";
import { URL } from "url";
//#region node_modules/.pnpm/https-proxy-agent@9.1.0/node_modules/https-proxy-agent/dist/parse-proxy-response.js
var import_src = /* @__PURE__ */ __toESM(require_src(), 1);
var debug$1 = (0, import_src.default)("https-proxy-agent:parse-proxy-response");
function parseProxyResponse(socket) {
	return new Promise((resolve, reject) => {
		let buffersLength = 0;
		const buffers = [];
		function read() {
			const b = socket.read();
			if (b) ondata(b);
			else socket.once("readable", read);
		}
		function cleanup() {
			socket.removeListener("end", onend);
			socket.removeListener("error", onerror);
			socket.removeListener("readable", read);
		}
		function onend() {
			cleanup();
			debug$1("onend");
			reject(/* @__PURE__ */ new Error("Proxy connection ended before receiving CONNECT response"));
		}
		function onerror(err) {
			cleanup();
			debug$1("onerror %o", err);
			reject(err);
		}
		function ondata(b) {
			buffers.push(b);
			buffersLength += b.length;
			const buffered = Buffer.concat(buffers, buffersLength);
			const endOfHeaders = buffered.indexOf("\r\n\r\n");
			if (endOfHeaders === -1) {
				debug$1("have not received end of HTTP headers yet...");
				read();
				return;
			}
			const headerParts = buffered.slice(0, endOfHeaders).toString("ascii").split("\r\n");
			const firstLine = headerParts.shift();
			if (!firstLine) {
				socket.destroy();
				return reject(/* @__PURE__ */ new Error("No header received from proxy CONNECT response"));
			}
			const firstLineParts = firstLine.split(" ");
			const statusCode = +firstLineParts[1];
			const statusText = firstLineParts.slice(2).join(" ");
			const headers = {};
			for (const header of headerParts) {
				if (!header) continue;
				const firstColon = header.indexOf(":");
				if (firstColon === -1) {
					socket.destroy();
					return reject(/* @__PURE__ */ new Error(`Invalid header from proxy CONNECT response: "${header}"`));
				}
				const key = header.slice(0, firstColon).toLowerCase();
				const value = header.slice(firstColon + 1).trimStart();
				const current = headers[key];
				if (typeof current === "string") headers[key] = [current, value];
				else if (Array.isArray(current)) current.push(value);
				else headers[key] = value;
			}
			debug$1("got proxy server response: %o %o", firstLine, headers);
			cleanup();
			resolve({
				connect: {
					statusCode,
					statusText,
					headers
				},
				buffered
			});
		}
		socket.on("error", onerror);
		socket.on("end", onend);
		read();
	});
}
//#endregion
//#region node_modules/.pnpm/proxy-agent-negotiate@1.1.0/node_modules/proxy-agent-negotiate/dist/index.js
function createNegotiateAuth() {
	return async ({ response, scheme }) => {
		if (scheme.toLowerCase() !== "negotiate") throw new Error(`Expected Negotiate scheme but got "${scheme}"`);
		let kerberos;
		try {
			kerberos = await import("../__vite-optional-peer-dep_kerberos_proxy-agent-negotiate.mjs");
		} catch {
			throw new Error("The \"kerberos\" package is required for Negotiate proxy authentication. Install it with: npm install kerberos");
		}
		const proxyAuthenticate = response.headers["proxy-authenticate"] || "";
		const challengeHeader = Array.isArray(proxyAuthenticate) ? proxyAuthenticate[0] : proxyAuthenticate;
		const serverToken = typeof challengeHeader === "string" && challengeHeader.includes(" ") ? challengeHeader.split(" ").slice(1).join(" ") : void 0;
		const token = await (await kerberos.initializeClient("HTTP@proxy", { mechOID: kerberos.GSS_MECH_OID_SPNEGO })).step(serverToken || "");
		if (!token) throw new Error("Kerberos client.step() returned no token");
		return { headers: { "Proxy-Authorization": `Negotiate ${token}` } };
	};
}
//#endregion
//#region node_modules/.pnpm/https-proxy-agent@9.1.0/node_modules/https-proxy-agent/dist/index.js
var debug = (0, import_src.default)("https-proxy-agent");
var setServernameFromNonIpHost = (options) => {
	if (options.servername === void 0 && options.host && !net.isIP(options.host)) return {
		...options,
		servername: options.host
	};
	return options;
};
/**
* The `HttpsProxyAgent` implements an HTTP Agent subclass that connects to
* the specified "HTTP(s) proxy server" in order to proxy HTTPS requests.
*
* Outgoing HTTP requests are first tunneled through the proxy server using the
* `CONNECT` HTTP request method to establish a connection to the proxy server,
* and then the proxy server connects to the destination target and issues the
* HTTP request from the proxy server.
*
* `https:` requests have their socket connection upgraded to TLS once
* the connection to the proxy server has been established.
*/
var HttpsProxyAgent = class extends Agent {
	constructor(proxy, opts) {
		super(opts);
		this.options = { path: void 0 };
		this.proxy = typeof proxy === "string" ? new URL(proxy) : proxy;
		this.proxyHeaders = opts?.headers ?? {};
		debug("Creating new HttpsProxyAgent instance: %o", this.proxy.href);
		if (opts?.negotiate) this.onProxyAuth = createNegotiateAuth();
		else if (opts?.onProxyAuth) this.onProxyAuth = opts.onProxyAuth;
		const host = (this.proxy.hostname || this.proxy.host).replace(/^\[|\]$/g, "");
		const port = this.proxy.port ? parseInt(this.proxy.port, 10) : this.proxy.protocol === "https:" ? 443 : 80;
		this.connectOpts = {
			ALPNProtocols: ["http/1.1"],
			...opts ? omit(opts, "headers", "onProxyAuth", "negotiate") : null,
			host,
			port
		};
	}
	/**
	* Called when the node-core HTTP client library is creating a
	* new HTTP request.
	*/
	async connect(req, opts) {
		const { proxy } = this;
		if (!opts.host) throw new TypeError("No \"host\" provided");
		let socket;
		if (proxy.protocol === "https:") {
			debug("Creating `tls.Socket`: %o", this.connectOpts);
			socket = tls.connect(setServernameFromNonIpHost(this.connectOpts));
		} else {
			debug("Creating `net.Socket`: %o", this.connectOpts);
			socket = net.connect(this.connectOpts);
		}
		const headers = typeof this.proxyHeaders === "function" ? this.proxyHeaders() : { ...this.proxyHeaders };
		const host = net.isIPv6(opts.host) ? `[${opts.host}]` : opts.host;
		let payload = `CONNECT ${host}:${opts.port} HTTP/1.1\r\n`;
		if (proxy.username || proxy.password) {
			const auth = `${decodeURIComponent(proxy.username)}:${decodeURIComponent(proxy.password)}`;
			headers["Proxy-Authorization"] = `Basic ${Buffer.from(auth).toString("base64")}`;
		}
		headers.Host = `${host}:${opts.port}`;
		if (!headers["Proxy-Connection"]) headers["Proxy-Connection"] = this.keepAlive ? "Keep-Alive" : "close";
		for (const name of Object.keys(headers)) payload += `${name}: ${headers[name]}\r\n`;
		const proxyResponsePromise = parseProxyResponse(socket);
		socket.write(`${payload}\r\n`);
		const { connect, buffered } = await proxyResponsePromise;
		req.emit("proxyConnect", connect);
		this.emit("proxyConnect", connect, req);
		req.emit("proxy", {
			proxy: this.proxy.href,
			socket
		});
		if (connect.statusCode === 200) {
			req.once("socket", resume);
			if (opts.secureEndpoint) {
				debug("Upgrading socket connection to TLS");
				return tls.connect({
					...omit(setServernameFromNonIpHost(opts), "host", "path", "port"),
					socket
				});
			}
			return socket;
		}
		if (connect.statusCode === 407 && this.onProxyAuth) {
			debug("Got 407 response, invoking onProxyAuth callback");
			socket.destroy();
			const proxyAuthenticate = connect.headers["proxy-authenticate"] || "";
			const scheme = Array.isArray(proxyAuthenticate) ? proxyAuthenticate[0].split(/\s/)[0] : proxyAuthenticate.split(/\s/)[0];
			const authResponse = await this.onProxyAuth({
				response: connect,
				scheme
			});
			return this._connectWithAuth(req, opts, authResponse.headers);
		}
		socket.destroy();
		const fakeSocket = new net.Socket({ writable: false });
		fakeSocket.readable = true;
		req.once("socket", (s) => {
			debug("Replaying proxy buffer for failed request");
			assert(s.listenerCount("data") > 0);
			s.push(buffered);
			s.push(null);
		});
		return fakeSocket;
	}
	/**
	* Retry a CONNECT request with additional auth headers.
	*/
	async _connectWithAuth(req, opts, authHeaders) {
		const { proxy } = this;
		let socket;
		if (proxy.protocol === "https:") socket = tls.connect(setServernameFromNonIpHost(this.connectOpts));
		else socket = net.connect(this.connectOpts);
		const headers = typeof this.proxyHeaders === "function" ? this.proxyHeaders() : { ...this.proxyHeaders };
		const host = net.isIPv6(opts.host) ? `[${opts.host}]` : opts.host;
		let payload = `CONNECT ${host}:${opts.port} HTTP/1.1\r\n`;
		if (proxy.username || proxy.password) {
			const auth = `${decodeURIComponent(proxy.username)}:${decodeURIComponent(proxy.password)}`;
			headers["Proxy-Authorization"] = `Basic ${Buffer.from(auth).toString("base64")}`;
		}
		Object.assign(headers, authHeaders);
		headers.Host = `${host}:${opts.port}`;
		if (!headers["Proxy-Connection"]) headers["Proxy-Connection"] = this.keepAlive ? "Keep-Alive" : "close";
		for (const name of Object.keys(headers)) payload += `${name}: ${headers[name]}\r\n`;
		const proxyResponsePromise = parseProxyResponse(socket);
		socket.write(`${payload}\r\n`);
		const { connect } = await proxyResponsePromise;
		req.emit("proxyConnect", connect);
		this.emit("proxyConnect", connect, req);
		if (connect.statusCode === 200) {
			req.once("socket", resume);
			if (opts.secureEndpoint) {
				debug("Upgrading socket connection to TLS");
				return tls.connect({
					...omit(setServernameFromNonIpHost(opts), "host", "path", "port"),
					socket
				});
			}
			return socket;
		}
		socket.destroy();
		throw new Error(`Proxy authentication failed with status ${connect.statusCode} after retry`);
	}
};
HttpsProxyAgent.protocols = ["http", "https"];
function resume(socket) {
	setImmediate(() => {
		socket.resume();
	});
}
function omit(obj, ...keys) {
	const ret = {};
	let key;
	for (key in obj) if (!keys.includes(key)) ret[key] = obj[key];
	return ret;
}
//#endregion
export { HttpsProxyAgent as t };

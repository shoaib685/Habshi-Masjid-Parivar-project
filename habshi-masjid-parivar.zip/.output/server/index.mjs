globalThis.__nitro_main__ = import.meta.url;
import { n as serve, t as NodeResponse } from "./_libs/srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/.pnpm/nitro@3.0.260603-beta_jiti@_3d600e81121cbd9d3dbc6a7cd146ba92/node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/manifest.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"2d7-u0yNaYADVVukZCQzaLC015J/8qk\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 727,
		"path": "../public/manifest.webmanifest"
	},
	"/offline.html": {
		"type": "text/html; charset=utf-8",
		"etag": "\"3b4-RTnvV1PF7YBEosZuiXCWxbLx6Uw\"",
		"mtime": "2026-11-13T08:33:48.340Z",
		"size": 948,
		"path": "../public/offline.html"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"1346-dsA74ZhV7gbPSbcaq2BplQjSJ0k\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 4934,
		"path": "../public/favicon.png"
	},
	"/sw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9cd-vbALMJQ4Wa8dsBDKAH5j4mvmSKU\"",
		"mtime": "2026-11-13T08:45:57.934Z",
		"size": 2509,
		"path": "../public/sw.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/admin-api-DcPRG9VV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f5e0-HpF+zUW8P4skwDT6m2d6/fviAlY\"",
		"mtime": "2026-11-13T09:34:12.632Z",
		"size": 62944,
		"path": "../public/assets/admin-api-DcPRG9VV.js"
	},
	"/assets/admin-CyWQjUEN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8eb5-EC79tz6GmrZAavqdwFv8ln3LbXU\"",
		"mtime": "2026-11-13T09:34:12.631Z",
		"size": 36533,
		"path": "../public/assets/admin-CyWQjUEN.js"
	},
	"/assets/admin_.login-Bk0kgJI7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"93a-bznEUWTjFF8AdxENP2EF81G0rlI\"",
		"mtime": "2026-11-13T09:34:12.633Z",
		"size": 2362,
		"path": "../public/assets/admin_.login-Bk0kgJI7.js"
	},
	"/assets/bell-ring-Cl0AiN5-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"186-kb0Ga+QNBx0DrnRXpDTj15DcQb8\"",
		"mtime": "2026-11-13T09:34:12.636Z",
		"size": 390,
		"path": "../public/assets/bell-ring-Cl0AiN5-.js"
	},
	"/assets/contributions-CLQ65AZd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c9-NkYoOFV39vcZM0Lc/LBNY2NKsBY\"",
		"mtime": "2026-11-13T09:34:12.638Z",
		"size": 201,
		"path": "../public/assets/contributions-CLQ65AZd.js"
	},
	"/assets/announcements-DEQ0wCym.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75d-PiutxENqtHYtBXimstKhQ8wMRCU\"",
		"mtime": "2026-11-13T09:34:12.634Z",
		"size": 1885,
		"path": "../public/assets/announcements-DEQ0wCym.js"
	},
	"/assets/button-CfJWSVHW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"63e-90qJ2l6H/Kqa+M+yaCCi07Jx4zk\"",
		"mtime": "2026-11-13T09:34:12.636Z",
		"size": 1598,
		"path": "../public/assets/button-CfJWSVHW.js"
	},
	"/assets/contributions-BXcQyBAA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10ca-q1fUqaCjRygpUVO9pPQa3zbQy3s\"",
		"mtime": "2026-11-13T09:34:12.638Z",
		"size": 4298,
		"path": "../public/assets/contributions-BXcQyBAA.js"
	},
	"/assets/date-DEq81QoK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ad-8wNnSpBtg1JytHAWThYSRaaOvBM\"",
		"mtime": "2026-11-13T09:34:12.639Z",
		"size": 685,
		"path": "../public/assets/date-DEq81QoK.js"
	},
	"/assets/dist-BBMFlg7E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c42-2Ffd1dZO6XSGDyTmeFIthS2nvkY\"",
		"mtime": "2026-11-13T09:34:12.640Z",
		"size": 3138,
		"path": "../public/assets/dist-BBMFlg7E.js"
	},
	"/assets/duty-DS9YJoZ5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"966-Rp6pEWRUzlftlBj20P81z6pSbCU\"",
		"mtime": "2026-11-13T09:34:12.641Z",
		"size": 2406,
		"path": "../public/assets/duty-DS9YJoZ5.js"
	},
	"/assets/DutyCards-CFCA3xux.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd4-zj+OulDP3qaNcSZWS4iWt+2eq4g\"",
		"mtime": "2026-11-13T09:34:12.630Z",
		"size": 3540,
		"path": "../public/assets/DutyCards-CFCA3xux.js"
	},
	"/assets/download-Cn4tOGJf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ce-KHafrWqELNOMhf1vb8ftUFn18Eg\"",
		"mtime": "2026-11-13T09:34:12.641Z",
		"size": 462,
		"path": "../public/assets/download-Cn4tOGJf.js"
	},
	"/assets/info-ClhlMqz3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c5-K6ZNY5qV4is86QE2WPqWjCVzM6U\"",
		"mtime": "2026-11-13T09:34:12.643Z",
		"size": 197,
		"path": "../public/assets/info-ClhlMqz3.js"
	},
	"/assets/input-CXID7-ID.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26d-gXqPbZGltUF5EQxKESH/UeLXhuQ\"",
		"mtime": "2026-11-13T09:34:12.645Z",
		"size": 621,
		"path": "../public/assets/input-CXID7-ID.js"
	},
	"/assets/map-pin-DlM7U0UQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"149-J3iqL9kTrv0YRmQjJDTegTaJHB0\"",
		"mtime": "2026-11-13T09:34:12.645Z",
		"size": 329,
		"path": "../public/assets/map-pin-DlM7U0UQ.js"
	},
	"/assets/preload-helper-CGBf8cxm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1450-cZUKPkscXGw1B1h2yX7gyfzaXSI\"",
		"mtime": "2026-11-13T09:34:12.647Z",
		"size": 5200,
		"path": "../public/assets/preload-helper-CGBf8cxm.js"
	},
	"/assets/index-D9MQ4N3i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56578-1R5keN+tPiI5lRsziXQD0AJLMVw\"",
		"mtime": "2026-11-13T09:34:12.628Z",
		"size": 353656,
		"path": "../public/assets/index-D9MQ4N3i.js"
	},
	"/assets/pin-DLYEwals.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"153-Xz3b2VILqNE3+lgjLyOzdkM+N4g\"",
		"mtime": "2026-11-13T09:34:12.646Z",
		"size": 339,
		"path": "../public/assets/pin-DLYEwals.js"
	},
	"/assets/react-dom-DMRjuTGV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f17-FHrZZTqVA5EgT9auYZz7y9E4lrY\"",
		"mtime": "2026-11-13T09:34:12.648Z",
		"size": 3863,
		"path": "../public/assets/react-dom-DMRjuTGV.js"
	},
	"/assets/routes-4u4bJ8GY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1116-/bwdLpAPedixaZ5roENYYhx3Mu8\"",
		"mtime": "2026-11-13T09:34:12.650Z",
		"size": 4374,
		"path": "../public/assets/routes-4u4bJ8GY.js"
	},
	"/assets/schedule-CALVvXCK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"638b-Ux8xsgbgjgEhehIxYjjPmIvcq0s\"",
		"mtime": "2026-11-13T09:34:12.652Z",
		"size": 25483,
		"path": "../public/assets/schedule-CALVvXCK.js"
	},
	"/assets/settings-PbwuR9sE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27da-5blByiH0L310Aofrfe8Yc4QB2LQ\"",
		"mtime": "2026-11-13T09:34:12.653Z",
		"size": 10202,
		"path": "../public/assets/settings-PbwuR9sE.js"
	},
	"/assets/smartphone-DHrpm_LU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be-aRLIuI/WetzvSXI6XL/fGa5b3SM\"",
		"mtime": "2026-11-13T09:34:12.658Z",
		"size": 190,
		"path": "../public/assets/smartphone-DHrpm_LU.js"
	},
	"/assets/styles-Co4YQCJw.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14b9e-07ZGUt6HFiwwRsJUw7qUcx64/vs\"",
		"mtime": "2026-11-13T09:34:12.680Z",
		"size": 84894,
		"path": "../public/assets/styles-Co4YQCJw.css"
	},
	"/assets/ui-DT-9oJcg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"89e-IUk2N22uzdMXd+C27F6u/cOg4I4\"",
		"mtime": "2026-11-13T09:34:12.662Z",
		"size": 2206,
		"path": "../public/assets/ui-DT-9oJcg.js"
	},
	"/assets/useNavigate-C0dz33EK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bf-sGqF/TSTbA+EGsm9ZwwTFpcFkys\"",
		"mtime": "2026-11-13T09:34:12.666Z",
		"size": 191,
		"path": "../public/assets/useNavigate-C0dz33EK.js"
	},
	"/assets/utils-DbguV03Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e43-C5YIRgxwQcW9GjfAYigYKkN1nQ4\"",
		"mtime": "2026-11-13T09:34:12.674Z",
		"size": 28227,
		"path": "../public/assets/utils-DbguV03Q.js"
	},
	"/icons/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"4d79-hrmyHKT1t6PMFpsHMOBaAi0Bsvk\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 19833,
		"path": "../public/icons/apple-touch-icon.png"
	},
	"/icons/icon-192.png": {
		"type": "image/png",
		"etag": "\"551c-7Mm+ficOa+KlqwbGRSZ9Sq3A4qg\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 21788,
		"path": "../public/icons/icon-192.png"
	},
	"/icons/icon-512.png": {
		"type": "image/png",
		"etag": "\"156a0-yohw/U/60MSXK1NnAgLVExHpyzo\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 87712,
		"path": "../public/icons/icon-512.png"
	},
	"/icons/maskable-512.png": {
		"type": "image/png",
		"etag": "\"10cf3-gLr/VwG+c7WScnJlsSvxqFt0z3E\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 68851,
		"path": "../public/icons/maskable-512.png"
	},
	"/splash/splash-1125x2436.png": {
		"type": "image/png",
		"etag": "\"14b43-Q90tfTTBdvvdtcj+/dXtvvApRzc\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 84803,
		"path": "../public/splash/splash-1125x2436.png"
	},
	"/splash/splash-1170x2532.png": {
		"type": "image/png",
		"etag": "\"16260-MhqD4kBFkpXEvw1iWUY+R9JElPA\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 90720,
		"path": "../public/splash/splash-1170x2532.png"
	},
	"/splash/splash-1179x2556.png": {
		"type": "image/png",
		"etag": "\"16431-t5UtxDQfjIFN+mi0hd91j+pGvAs\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 91185,
		"path": "../public/splash/splash-1179x2556.png"
	},
	"/splash/splash-1290x2796.png": {
		"type": "image/png",
		"etag": "\"19123-z6+5l776xhRuQ3/Fv7Sw6N3Fz+w\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 102691,
		"path": "../public/splash/splash-1290x2796.png"
	},
	"/splash/splash-750x1334.png": {
		"type": "image/png",
		"etag": "\"b89a-Q8sFUXhmCm1melesYPtlFGkTfd0\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 47258,
		"path": "../public/splash/splash-750x1334.png"
	},
	"/splash/splash-1284x2778.png": {
		"type": "image/png",
		"etag": "\"18eb7-Kux1bLgjy6ROE5dzbbA0/77gW6Y\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 102071,
		"path": "../public/splash/splash-1284x2778.png"
	},
	"/splash/splash-828x1792.png": {
		"type": "image/png",
		"etag": "\"dcd0-psKfzrtvUZEYhXvaz8GoYVFKCY8\"",
		"mtime": "2026-11-09T11:14:35.000Z",
		"size": 56528,
		"path": "../public/splash/splash-828x1792.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/.pnpm/nitro@3.0.260603-beta_jiti@_3d600e81121cbd9d3dbc6a7cd146ba92/node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_JF4FTF = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_JF4FTF
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/.pnpm/nitro@3.0.260603-beta_jiti@_3d600e81121cbd9d3dbc6a7cd146ba92/node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/.pnpm/nitro@3.0.260603-beta_jiti@_3d600e81121cbd9d3dbc6a7cd146ba92/node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/.pnpm/nitro@3.0.260603-beta_jiti@_3d600e81121cbd9d3dbc6a7cd146ba92/node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/.pnpm/nitro@3.0.260603-beta_jiti@_3d600e81121cbd9d3dbc6a7cd146ba92/node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };

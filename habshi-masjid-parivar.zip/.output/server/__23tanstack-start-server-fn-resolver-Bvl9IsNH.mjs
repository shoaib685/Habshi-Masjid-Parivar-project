//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-Bvl9IsNH.js
var manifest = {
	"05c4a016655e0329b56236b197fd1494c1369126db161d83195ca29745585b53": {
		functionName: "issueFamilyPushCode_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"087e18b0b1b03f6adaf70954aa4cdbb5664291b81b9ee72ca44036d06eba1f19": {
		functionName: "updateAnnouncement_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"0a85feaa4f0c0f889baa14879e7f05c60544e30d6d6013a837d1177f5a9cb789": {
		functionName: "subscribeFamilyPush_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"1300736cc7aba35c5570b76c752dd0c7b20e92ce7ba93216ee8373130c841862": {
		functionName: "exportAdminData_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"1e675813f744cc8dd80722dc46c702891955c246516207c98c0365a51828fe4d": {
		functionName: "updateFamily_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"1eab9d132768bdafdc65b33e25e4f903cd4c52de98aec914f8da35dace92a072": {
		functionName: "loginAdmin_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"29af26f21b77e455b7f0a5fb0a6ba5313610cac834ad3f7c81d88dd6debef88e": {
		functionName: "createFamily_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"36fdbe0f2f1b12dfea097a8fc7e50362c5f76a61e027c68c9f5241a6793dbb20": {
		functionName: "removeAnnouncement_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"3798b847917dbc38e09d62e6b186c9cffd00edf5319d9f3d0c81686b56cef006": {
		functionName: "saveFamilyPayment_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"4232dfb53cba7370a9b72a77d256435bda64b1a316b0d3b90561161f12ed2e80": {
		functionName: "createAnnouncement_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"5f3a908e03039500f8a20d5524c4c991c2eeba9728bfd1e8eea16c5407092e05": {
		functionName: "getPublicHomeData_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"5f74ff7d2af2d08eb1955e3a6cf57552f02ea306585cbb29e82a7ce7a13edc6f": {
		functionName: "createFoodEntry_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"6170a0edf0250863be9d8b49271e353d5b611b71e57e813dd1637cd0cde721ef": {
		functionName: "recordContribution_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"653e1729ba5eb3418da627af40a05761a45ae5a649d16e6b0addb273eb37a69d": {
		functionName: "getPublicContributions_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"6a3155a33aaff31ec66babd76ab9de47b3f8c0a01473446d8945c7414e898637": {
		functionName: "updateAppSettings_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"6a8ee610d51f73fefdabb81054f4d4f3b87a4f459e7f9779128ce54ad5b459f7": {
		functionName: "getAdminSnapshot_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"7530b3188d63024a7dc29ce58dc7e075ff20d57e9b89bac0ebc459e31424256d": {
		functionName: "getPublicSchedule_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"79224b5fd95c789c7e5fdcf6abfe09d41d75e59fddb39af91891439bb93379d7": {
		functionName: "logoutAdmin_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"7eb70b42329ee0a51d1c5c5efab0d2f101cb3c4fbf315decb9f34a8780fcf3c4": {
		functionName: "removeFoodEntry_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"850115e2cd0fad0d30b83b89237afd1e39d461b2cfc13d447f682b11b620dab6": {
		functionName: "getPublicAnnouncements_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"8b5712bdb7e546818e3cc2fbe6c2eeb8e02821fca4281c0f1456167c38043c3b": {
		functionName: "setDuty_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"8ee5bf2d60bbe64d8347437de200cf3fc443ea3636172ddb932465769ffd28d2": {
		functionName: "removeFamilyPushSubscription_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"aa132b913dc885918e0a3a51d7dd4fa6f7cf9770073af8dc7b8672762c0ba3d5": {
		functionName: "getPublicDutyData_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"d0739ef64ca32153770dd8f14f02643989f575ead95280feba6c10866b953036": {
		functionName: "getPublicPushConfig_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"e684a66cdc976cf7dd1af0523f720500a2d35bb6175f57f2cad6a9a80f9d67ae": {
		functionName: "updateFoodEntry_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	},
	"f9014ac7d2c5cd4774ab45450be55d60658d7e56f0421bcd22f8366d2c105216": {
		functionName: "checkAdminSession_createServerFn_handler",
		importer: () => import("./_ssr/admin-api-CWzrXqyo.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };

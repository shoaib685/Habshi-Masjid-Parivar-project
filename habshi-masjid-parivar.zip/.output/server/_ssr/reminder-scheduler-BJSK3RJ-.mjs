import { runDueDutyReminders } from "./duty-notifications-rCtDFG9d.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reminder-scheduler-BJSK3RJ-.js
function startReminderScheduler(intervalMs = 15e3) {
	let running = false;
	const tick = () => {
		if (running) return;
		running = true;
		runDueDutyReminders().catch((error) => {
			console.error("Duty reminder scheduler failed.", error);
		}).finally(() => {
			running = false;
		});
	};
	tick();
	const timer = setInterval(tick, intervalMs);
	timer.unref?.();
	return () => clearInterval(timer);
}
//#endregion
export { startReminderScheduler };

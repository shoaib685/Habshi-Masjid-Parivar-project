import { r as summarizeContributions } from "./contributions-Cg-XokK7.mjs";
import { c as shiftMonth, l as todayIST, n as addDays, o as monthKeyOf } from "./date-0gm0zi69.mjs";
import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-klzoUz4R.mjs";
import { a as numberType, o as objectType, s as stringType } from "../_libs/zod.mjs";
import { c as paymentInputSchema, i as dutyInputSchema, l as pushSubscriptionInputSchema, n as contributionInputSchema, o as familyInputSchema, s as foodSchema, t as announcementSchema, u as settingsSchema } from "./data-schemas-gms4ftdc.mjs";
import { n as getSchedule, t as getDutyForDate } from "./rotation-RQTt1xw8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-api-CWzrXqyo.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var credentialsSchema = objectType({ password: stringType().min(1).max(200) });
var idSchema = objectType({ id: stringType().uuid() });
var foodInputSchema = foodSchema.omit({
	id: true,
	updatedAt: true
});
var announcementInputSchema = announcementSchema.omit({ id: true });
var settingsInputSchema = settingsSchema.omit({ timezone: true });
var pushRemovalSchema = objectType({
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	registrationCode: stringType().min(8).max(64),
	endpoint: stringType().url()
});
async function requireAdmin() {
	const [{ getRequestHeader }, { getSessionToken, verifyAdminSession }] = await Promise.all([import("./server-Dhdt_04u.mjs"), import("./auth-BNuHMgqD.mjs")]);
	if (!verifyAdminSession(getSessionToken(getRequestHeader("cookie")))) throw new Error("Admin authentication is required.");
}
var loginAdmin_createServerFn_handler = createServerRpc({
	id: "1eab9d132768bdafdc65b33e25e4f903cd4c52de98aec914f8da35dace92a072",
	name: "loginAdmin",
	filename: "src/lib/admin-api.ts"
}, (opts) => loginAdmin.__executeServer(opts));
var loginAdmin = createServerFn({ method: "POST" }).validator(credentialsSchema).handler(loginAdmin_createServerFn_handler, async ({ data }) => {
	const { checkLoginRateLimit, clearFailedLogins, createAdminSession, recordFailedLogin, sessionCookie, verifyAdminPassword } = await import("./auth-BNuHMgqD.mjs");
	const [{ getRequestHeader, setResponseHeader }, { env }] = await Promise.all([import("./server-Dhdt_04u.mjs"), import("node:process")]);
	const clientKey = getRequestHeader("x-real-ip") ?? getRequestHeader("cf-connecting-ip") ?? "unknown-client";
	if (!checkLoginRateLimit(clientKey)) throw new Error("Too many sign-in attempts. Try again later.");
	if (!await verifyAdminPassword(data.password)) {
		recordFailedLogin(clientKey);
		throw new Error("Incorrect admin passcode.");
	}
	clearFailedLogins(clientKey);
	setResponseHeader("Set-Cookie", sessionCookie(createAdminSession(), env["NODE_ENV"] === "production"));
	return { authenticated: true };
});
var checkAdminSession_createServerFn_handler = createServerRpc({
	id: "f9014ac7d2c5cd4774ab45450be55d60658d7e56f0421bcd22f8366d2c105216",
	name: "checkAdminSession",
	filename: "src/lib/admin-api.ts"
}, (opts) => checkAdminSession.__executeServer(opts));
var checkAdminSession = createServerFn({ method: "GET" }).handler(checkAdminSession_createServerFn_handler, async () => {
	const [{ getRequestHeader }, { getSessionToken, verifyAdminSession }] = await Promise.all([import("./server-Dhdt_04u.mjs"), import("./auth-BNuHMgqD.mjs")]);
	return { authenticated: verifyAdminSession(getSessionToken(getRequestHeader("cookie"))) };
});
var logoutAdmin_createServerFn_handler = createServerRpc({
	id: "79224b5fd95c789c7e5fdcf6abfe09d41d75e59fddb39af91891439bb93379d7",
	name: "logoutAdmin",
	filename: "src/lib/admin-api.ts"
}, (opts) => logoutAdmin.__executeServer(opts));
var logoutAdmin = createServerFn({ method: "POST" }).handler(logoutAdmin_createServerFn_handler, async () => {
	const [{ setResponseHeader }, { clearedSessionCookie }, { env }] = await Promise.all([
		import("./server-Dhdt_04u.mjs"),
		import("./auth-BNuHMgqD.mjs"),
		import("node:process")
	]);
	setResponseHeader("Set-Cookie", clearedSessionCookie(env["NODE_ENV"] === "production"));
	return { authenticated: false };
});
var getPublicHomeData_createServerFn_handler = createServerRpc({
	id: "5f3a908e03039500f8a20d5524c4c991c2eeba9728bfd1e8eea16c5407092e05",
	name: "getPublicHomeData",
	filename: "src/lib/admin-api.ts"
}, (opts) => getPublicHomeData.__executeServer(opts));
var getPublicHomeData = createServerFn({ method: "GET" }).handler(getPublicHomeData_createServerFn_handler, async () => {
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const [storedFamilies, duties, foods, contributions, announcements, settings] = await Promise.all([
		jsonStore.read("families"),
		jsonStore.read("duties"),
		jsonStore.read("food"),
		jsonStore.read("contributions"),
		jsonStore.read("announcements"),
		jsonStore.read("settings")
	]);
	const today = todayIST();
	const rotation = makeRotationConfig(storedFamilies, duties, settings.anchorDate);
	const schedule = getSchedule(addDays(today, 1), 5, rotation, today);
	const duty = getDutyForDate(today, rotation, today);
	const month = monthKeyOf(today);
	const summary = summarizeContributions(month, contributions);
	const latest = [...announcements].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.date.localeCompare(a.date))[0];
	return {
		today,
		duty: publicDuty(applyStoredDuty(duty, duties, storedFamilies)),
		schedule: schedule.map((day) => publicDuty(applyStoredDuty(day, duties, storedFamilies))),
		food: foods.filter((item) => item.date === today).sort((a, b) => a.updatedAt.localeCompare(b.updatedAt)).map(({ id, title, description, date, updatedAt }) => ({
			id,
			title,
			description,
			date,
			updatedAt
		})),
		month,
		summary,
		announcement: latest ? {
			id: latest.id,
			title: latest.title,
			body: latest.body,
			tag: latest.tag,
			pinned: latest.pinned
		} : null
	};
});
var getPublicPushConfig_createServerFn_handler = createServerRpc({
	id: "d0739ef64ca32153770dd8f14f02643989f575ead95280feba6c10866b953036",
	name: "getPublicPushConfig",
	filename: "src/lib/admin-api.ts"
}, (opts) => getPublicPushConfig.__executeServer(opts));
var getPublicPushConfig = createServerFn({ method: "GET" }).handler(getPublicPushConfig_createServerFn_handler, async () => {
	const { getPushPublicKey } = await import("./push-provider-Dwk2D3sx.mjs").then((n) => n.t).then((n) => n.t);
	return { publicKey: getPushPublicKey() };
});
var subscribeFamilyPush_createServerFn_handler = createServerRpc({
	id: "0a85feaa4f0c0f889baa14879e7f05c60544e30d6d6013a837d1177f5a9cb789",
	name: "subscribeFamilyPush",
	filename: "src/lib/admin-api.ts"
}, (opts) => subscribeFamilyPush.__executeServer(opts));
var subscribeFamilyPush = createServerFn({ method: "POST" }).validator(pushSubscriptionInputSchema).handler(subscribeFamilyPush_createServerFn_handler, async ({ data }) => {
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const { randomUUID } = await import("node:crypto");
	const family = (await jsonStore.read("families")).find((item) => item.id === data.familyId && item.active);
	if (!family) throw new Error("Choose an active family.");
	if (!family.notificationCodeHash || !await matchesEnrollmentCode(data.registrationCode, family.notificationCodeHash)) throw new Error("Family ID or notification setup code is incorrect.");
	const now = (/* @__PURE__ */ new Date()).toISOString();
	let savedId = "";
	await jsonStore.update("pushSubscriptions", (subscriptions) => {
		const current = subscriptions.find((item) => item.endpoint === data.endpoint);
		savedId = current?.id ?? randomUUID();
		const updated = {
			id: savedId,
			familyId: family.id,
			endpoint: data.endpoint,
			keys: data.keys,
			expirationTime: data.expirationTime,
			createdAt: current?.createdAt ?? now,
			updatedAt: now
		};
		return current ? subscriptions.map((item) => item.endpoint === data.endpoint ? updated : item) : [...subscriptions, updated];
	});
	return {
		saved: true,
		subscriptionId: savedId
	};
});
var removeFamilyPushSubscription_createServerFn_handler = createServerRpc({
	id: "8ee5bf2d60bbe64d8347437de200cf3fc443ea3636172ddb932465769ffd28d2",
	name: "removeFamilyPushSubscription",
	filename: "src/lib/admin-api.ts"
}, (opts) => removeFamilyPushSubscription.__executeServer(opts));
var removeFamilyPushSubscription = createServerFn({ method: "POST" }).validator(pushRemovalSchema).handler(removeFamilyPushSubscription_createServerFn_handler, async ({ data }) => {
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const family = (await jsonStore.read("families")).find((item) => item.id === data.familyId);
	if (!family?.notificationCodeHash || !await matchesEnrollmentCode(data.registrationCode, family.notificationCodeHash)) throw new Error("Family ID or notification setup code is incorrect.");
	let removed = false;
	await jsonStore.update("pushSubscriptions", (subscriptions) => {
		const remaining = subscriptions.filter((item) => item.endpoint !== data.endpoint || item.familyId !== family.id);
		removed = remaining.length !== subscriptions.length;
		return remaining;
	});
	return { removed };
});
var issueFamilyPushCode_createServerFn_handler = createServerRpc({
	id: "05c4a016655e0329b56236b197fd1494c1369126db161d83195ca29745585b53",
	name: "issueFamilyPushCode",
	filename: "src/lib/admin-api.ts"
}, (opts) => issueFamilyPushCode.__executeServer(opts));
var issueFamilyPushCode = createServerFn({ method: "POST" }).validator(objectType({ familyId: stringType().regex(/^HMP-\d{3,}$/) })).handler(issueFamilyPushCode_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const { randomBytes } = await import("node:crypto");
	const code = randomBytes(9).toString("base64url").toUpperCase();
	const hash = await enrollmentCodeHash(code);
	let found = false;
	await jsonStore.update("families", (families) => families.map((family) => {
		if (family.id !== data.familyId) return family;
		found = true;
		return {
			...family,
			notificationCodeHash: hash
		};
	}));
	if (!found) throw new Error("Family not found.");
	return { code };
});
var getPublicSchedule_createServerFn_handler = createServerRpc({
	id: "7530b3188d63024a7dc29ce58dc7e075ff20d57e9b89bac0ebc459e31424256d",
	name: "getPublicSchedule",
	filename: "src/lib/admin-api.ts"
}, (opts) => getPublicSchedule.__executeServer(opts));
var getPublicSchedule = createServerFn({ method: "GET" }).handler(getPublicSchedule_createServerFn_handler, async () => {
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const [storedFamilies, duties, settings] = await Promise.all([
		jsonStore.read("families"),
		jsonStore.read("duties"),
		jsonStore.read("settings")
	]);
	const today = todayIST();
	return {
		today,
		schedule: getSchedule(addDays(today, -7), 28, makeRotationConfig(storedFamilies, duties, settings.anchorDate), today).map((day) => publicDuty(applyStoredDuty(day, duties, storedFamilies)))
	};
});
var getPublicDutyData_createServerFn_handler = createServerRpc({
	id: "aa132b913dc885918e0a3a51d7dd4fa6f7cf9770073af8dc7b8672762c0ba3d5",
	name: "getPublicDutyData",
	filename: "src/lib/admin-api.ts"
}, (opts) => getPublicDutyData.__executeServer(opts));
var getPublicDutyData = createServerFn({ method: "GET" }).handler(getPublicDutyData_createServerFn_handler, async () => {
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const [storedFamilies, duties, settings] = await Promise.all([
		jsonStore.read("families"),
		jsonStore.read("duties"),
		jsonStore.read("settings")
	]);
	const today = todayIST();
	const config = makeRotationConfig(storedFamilies, duties, settings.anchorDate);
	return {
		today,
		duty: publicDuty(applyStoredDuty(getDutyForDate(today, config, today), duties, storedFamilies)),
		yesterday: publicDuty(applyStoredDuty(getDutyForDate(addDays(today, -1), config, today), duties, storedFamilies)),
		tomorrow: publicDuty(applyStoredDuty(getDutyForDate(addDays(today, 1), config, today), duties, storedFamilies)),
		history: getSchedule(addDays(today, -7), 7, config, today).reverse().map((day) => publicDuty(applyStoredDuty(day, duties, storedFamilies)))
	};
});
var getPublicAnnouncements_createServerFn_handler = createServerRpc({
	id: "850115e2cd0fad0d30b83b89237afd1e39d461b2cfc13d447f682b11b620dab6",
	name: "getPublicAnnouncements",
	filename: "src/lib/admin-api.ts"
}, (opts) => getPublicAnnouncements.__executeServer(opts));
var getPublicAnnouncements = createServerFn({ method: "GET" }).handler(getPublicAnnouncements_createServerFn_handler, async () => {
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	return [...await jsonStore.read("announcements")].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.date.localeCompare(a.date)).map(({ id, title, body, date, tag, pinned }) => ({
		id,
		title,
		body,
		date,
		tag,
		pinned
	}));
});
var getPublicContributions_createServerFn_handler = createServerRpc({
	id: "653e1729ba5eb3418da627af40a05761a45ae5a649d16e6b0addb273eb37a69d",
	name: "getPublicContributions",
	filename: "src/lib/admin-api.ts"
}, (opts) => getPublicContributions.__executeServer(opts));
var getPublicContributions = createServerFn({ method: "GET" }).handler(getPublicContributions_createServerFn_handler, async () => {
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const contributions = await jsonStore.read("contributions");
	const currentMonth = monthKeyOf(todayIST());
	return Array.from({ length: 6 }, (_, index) => {
		return summarizeContributions(shiftMonth(currentMonth, index - 5), contributions);
	});
});
var getAdminSnapshot_createServerFn_handler = createServerRpc({
	id: "6a8ee610d51f73fefdabb81054f4d4f3b87a4f459e7f9779128ce54ad5b459f7",
	name: "getAdminSnapshot",
	filename: "src/lib/admin-api.ts"
}, (opts) => getAdminSnapshot.__executeServer(opts));
var getAdminSnapshot = createServerFn({ method: "GET" }).handler(getAdminSnapshot_createServerFn_handler, async () => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const [families, duties, foods, payments, contributions, announcements, notifications, settings] = await Promise.all([
		jsonStore.read("families"),
		jsonStore.read("duties"),
		jsonStore.read("food"),
		jsonStore.read("payments"),
		jsonStore.read("contributions"),
		jsonStore.read("announcements"),
		jsonStore.read("notifications"),
		jsonStore.read("settings")
	]);
	const today = todayIST();
	const month = monthKeyOf(today);
	const config = makeRotationConfig(families, duties, settings.anchorDate);
	return {
		families: families.map((family) => {
			const record = { ...family };
			delete record.notificationCodeHash;
			return record;
		}),
		duties,
		foods,
		payments,
		contributions,
		announcements,
		notifications,
		settings,
		today,
		month,
		schedule: getSchedule(addDays(today, -7), 35, config, today).map((day) => publicDuty(applyStoredDuty(day, duties, families))),
		contributionSummary: summarizeContributions(month, contributions)
	};
});
var createFamily_createServerFn_handler = createServerRpc({
	id: "29af26f21b77e455b7f0a5fb0a6ba5313610cac834ad3f7c81d88dd6debef88e",
	name: "createFamily",
	filename: "src/lib/admin-api.ts"
}, (opts) => createFamily.__executeServer(opts));
var createFamily = createServerFn({ method: "POST" }).validator(familyInputSchema).handler(createFamily_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const [current, duties, settings] = await Promise.all([
		jsonStore.read("families"),
		jsonStore.read("duties"),
		jsonStore.read("settings")
	]);
	await materializePastDuties(current, duties, settings.anchorDate);
	let createdFamily;
	await jsonStore.update("families", (families) => {
		const nextNumber = families.reduce((max, family) => {
			const value = Number(family.id.slice(4));
			return Number.isFinite(value) ? Math.max(max, value) : max;
		}, 0) + 1;
		createdFamily = {
			...data,
			id: `HMP-${String(nextNumber).padStart(3, "0")}`,
			order: Math.max(0, ...families.map((item) => item.order)) + 1
		};
		return [...families, createdFamily];
	});
	if (!createdFamily) throw new Error("Family was not created.");
	return createdFamily;
});
var updateFamily_createServerFn_handler = createServerRpc({
	id: "1e675813f744cc8dd80722dc46c702891955c246516207c98c0365a51828fe4d",
	name: "updateFamily",
	filename: "src/lib/admin-api.ts"
}, (opts) => updateFamily.__executeServer(opts));
var updateFamily = createServerFn({ method: "POST" }).validator(familyInputSchema.extend({
	id: stringType().regex(/^HMP-\d{3,}$/),
	order: numberType().int().min(1)
})).handler(updateFamily_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const [current, duties, settings] = await Promise.all([
		jsonStore.read("families"),
		jsonStore.read("duties"),
		jsonStore.read("settings")
	]);
	if (current.some((family) => family.id !== data.id && family.order === data.order)) throw new Error("Each family must have a unique rotation order.");
	await materializePastDuties(current, duties, settings.anchorDate);
	const { id, ...updates } = data;
	let updated = false;
	await jsonStore.update("families", (families) => families.map((family) => {
		if (family.id !== id) return family;
		updated = true;
		return {
			...family,
			...updates
		};
	}));
	if (!updated) throw new Error("Family not found.");
	return { id };
});
var setDuty_createServerFn_handler = createServerRpc({
	id: "8b5712bdb7e546818e3cc2fbe6c2eeb8e02821fca4281c0f1456167c38043c3b",
	name: "setDuty",
	filename: "src/lib/admin-api.ts"
}, (opts) => setDuty.__executeServer(opts));
var setDuty = createServerFn({ method: "POST" }).validator(dutyInputSchema).handler(setDuty_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const families = await jsonStore.read("families");
	if (data.familyId && !families.some((family) => family.id === data.familyId && family.active)) throw new Error("Only an active family can be assigned a duty.");
	if (data.familyId && data.status === "skipped") throw new Error("A skipped duty cannot have a family assigned.");
	await jsonStore.update("duties", (duties) => {
		const existing = duties.find((duty) => duty.date === data.date);
		const next = { ...data };
		return existing ? duties.map((duty) => duty.date === data.date ? next : duty) : [...duties, next];
	});
	return { date: data.date };
});
var createFoodEntry_createServerFn_handler = createServerRpc({
	id: "5f74ff7d2af2d08eb1955e3a6cf57552f02ea306585cbb29e82a7ce7a13edc6f",
	name: "createFoodEntry",
	filename: "src/lib/admin-api.ts"
}, (opts) => createFoodEntry.__executeServer(opts));
var createFoodEntry = createServerFn({ method: "POST" }).validator(foodInputSchema).handler(createFoodEntry_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { randomUUID } = await import("node:crypto");
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const entry = {
		...data,
		id: randomUUID(),
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	await jsonStore.update("food", (food) => [...food, entry]);
	return entry;
});
var removeFoodEntry_createServerFn_handler = createServerRpc({
	id: "7eb70b42329ee0a51d1c5c5efab0d2f101cb3c4fbf315decb9f34a8780fcf3c4",
	name: "removeFoodEntry",
	filename: "src/lib/admin-api.ts"
}, (opts) => removeFoodEntry.__executeServer(opts));
var removeFoodEntry = createServerFn({ method: "POST" }).validator(idSchema).handler(removeFoodEntry_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	let removed = false;
	await jsonStore.update("food", (food) => {
		const next = food.filter((entry) => entry.id !== data.id);
		removed = next.length !== food.length;
		return next;
	});
	if (!removed) throw new Error("Food entry not found.");
	return { removed: true };
});
var updateFoodEntry_createServerFn_handler = createServerRpc({
	id: "e684a66cdc976cf7dd1af0523f720500a2d35bb6175f57f2cad6a9a80f9d67ae",
	name: "updateFoodEntry",
	filename: "src/lib/admin-api.ts"
}, (opts) => updateFoodEntry.__executeServer(opts));
var updateFoodEntry = createServerFn({ method: "POST" }).validator(foodInputSchema.extend({ id: stringType().uuid() })).handler(updateFoodEntry_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const { id, ...updates } = data;
	let found = false;
	await jsonStore.update("food", (food) => food.map((entry) => {
		if (entry.id !== id) return entry;
		found = true;
		return {
			...entry,
			...updates,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
	}));
	if (!found) throw new Error("Food entry not found.");
	return { id };
});
var saveFamilyPayment_createServerFn_handler = createServerRpc({
	id: "3798b847917dbc38e09d62e6b186c9cffd00edf5319d9f3d0c81686b56cef006",
	name: "saveFamilyPayment",
	filename: "src/lib/admin-api.ts"
}, (opts) => saveFamilyPayment.__executeServer(opts));
var saveFamilyPayment = createServerFn({ method: "POST" }).validator(paymentInputSchema).handler(saveFamilyPayment_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { randomUUID } = await import("node:crypto");
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	if (!(await jsonStore.read("families")).some((family) => family.id === data.familyId)) throw new Error("Choose an existing family.");
	let savedPayment;
	await jsonStore.update("payments", (payments) => {
		const existing = payments.find((payment) => payment.familyId === data.familyId && payment.month === data.month);
		const amountReceived = (existing?.amountReceived ?? 0) + data.amountPaid;
		if (amountReceived > data.amountDue) throw new Error("Total payments cannot exceed the amount due.");
		const history = [...existing?.history ?? [], ...data.amountPaid > 0 ? [{
			id: randomUUID(),
			at: (/* @__PURE__ */ new Date()).toISOString(),
			amount: data.amountPaid,
			method: data.method,
			note: data.note
		}] : []];
		const record = {
			id: existing?.id ?? randomUUID(),
			familyId: data.familyId,
			month: data.month,
			amountDue: data.amountDue,
			amountReceived,
			history
		};
		savedPayment = record;
		return existing ? payments.map((payment) => payment.id === existing.id ? record : payment) : [...payments, record];
	});
	if (!savedPayment) throw new Error("Payment record was not saved.");
	return savedPayment;
});
var recordContribution_createServerFn_handler = createServerRpc({
	id: "6170a0edf0250863be9d8b49271e353d5b611b71e57e813dd1637cd0cde721ef",
	name: "recordContribution",
	filename: "src/lib/admin-api.ts"
}, (opts) => recordContribution.__executeServer(opts));
var recordContribution = createServerFn({ method: "POST" }).validator(contributionInputSchema).handler(recordContribution_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { randomUUID } = await import("node:crypto");
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	if (!(await jsonStore.read("families")).some((family) => family.id === data.familyId)) throw new Error("Choose an existing family.");
	const record = {
		...data,
		id: randomUUID()
	};
	await jsonStore.update("contributions", (contributions) => [...contributions, record]);
	return record;
});
var createAnnouncement_createServerFn_handler = createServerRpc({
	id: "4232dfb53cba7370a9b72a77d256435bda64b1a316b0d3b90561161f12ed2e80",
	name: "createAnnouncement",
	filename: "src/lib/admin-api.ts"
}, (opts) => createAnnouncement.__executeServer(opts));
var createAnnouncement = createServerFn({ method: "POST" }).validator(announcementInputSchema).handler(createAnnouncement_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { randomUUID } = await import("node:crypto");
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const announcement = {
		...data,
		id: randomUUID()
	};
	await jsonStore.update("announcements", (items) => [...items, announcement]);
	return announcement;
});
var removeAnnouncement_createServerFn_handler = createServerRpc({
	id: "36fdbe0f2f1b12dfea097a8fc7e50362c5f76a61e027c68c9f5241a6793dbb20",
	name: "removeAnnouncement",
	filename: "src/lib/admin-api.ts"
}, (opts) => removeAnnouncement.__executeServer(opts));
var removeAnnouncement = createServerFn({ method: "POST" }).validator(idSchema).handler(removeAnnouncement_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	let removed = false;
	await jsonStore.update("announcements", (items) => {
		const next = items.filter((item) => item.id !== data.id);
		removed = next.length !== items.length;
		return next;
	});
	if (!removed) throw new Error("Announcement not found.");
	return { removed: true };
});
var updateAnnouncement_createServerFn_handler = createServerRpc({
	id: "087e18b0b1b03f6adaf70954aa4cdbb5664291b81b9ee72ca44036d06eba1f19",
	name: "updateAnnouncement",
	filename: "src/lib/admin-api.ts"
}, (opts) => updateAnnouncement.__executeServer(opts));
var updateAnnouncement = createServerFn({ method: "POST" }).validator(announcementInputSchema.extend({ id: stringType().uuid() })).handler(updateAnnouncement_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const { id, ...updates } = data;
	let found = false;
	await jsonStore.update("announcements", (items) => items.map((item) => {
		if (item.id !== id) return item;
		found = true;
		return {
			...item,
			...updates
		};
	}));
	if (!found) throw new Error("Announcement not found.");
	return { id };
});
var exportAdminData_createServerFn_handler = createServerRpc({
	id: "1300736cc7aba35c5570b76c752dd0c7b20e92ce7ba93216ee8373130c841862",
	name: "exportAdminData",
	filename: "src/lib/admin-api.ts"
}, (opts) => exportAdminData.__executeServer(opts));
var exportAdminData = createServerFn({ method: "GET" }).handler(exportAdminData_createServerFn_handler, async () => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	return jsonStore.exportAll();
});
var updateAppSettings_createServerFn_handler = createServerRpc({
	id: "6a3155a33aaff31ec66babd76ab9de47b3f8c0a01473446d8945c7414e898637",
	name: "updateAppSettings",
	filename: "src/lib/admin-api.ts"
}, (opts) => updateAppSettings.__executeServer(opts));
var updateAppSettings = createServerFn({ method: "POST" }).validator(settingsInputSchema).handler(updateAppSettings_createServerFn_handler, async ({ data }) => {
	await requireAdmin();
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	const [settings, duties, families] = await Promise.all([
		jsonStore.read("settings"),
		jsonStore.read("duties"),
		jsonStore.read("families")
	]);
	if (data.anchorDate !== settings.anchorDate) await materializePastDuties(families, duties, settings.anchorDate);
	await jsonStore.update("settings", (current) => ({
		...current,
		...data
	}));
	return { saved: true };
});
function makeRotationConfig(families, records, anchorDate) {
	const overrides = records.flatMap((duty) => {
		if (duty.status === "skipped") return [{
			date: duty.date,
			kind: "skip",
			note: duty.note
		}];
		if (duty.status === "overridden" && duty.familyId) return [{
			date: duty.date,
			kind: "reassign",
			familyId: duty.familyId,
			note: duty.note
		}];
		return [];
	});
	return {
		families: families.map((family) => ({ ...family })),
		anchorDate,
		overrides
	};
}
function applyStoredDuty(duty, records, families) {
	const saved = records.find((record) => record.date === duty.date);
	if (!saved) return duty;
	const savedFamily = saved.familyId ? families.find((family) => family.id === saved.familyId) ?? null : null;
	if (saved.status === "completed") return {
		...duty,
		family: savedFamily,
		status: "completed",
		override: void 0
	};
	if (saved.status === "overridden" || saved.status === "skipped") return {
		...duty,
		family: saved.status === "skipped" ? null : savedFamily,
		status: saved.status,
		override: {
			date: saved.date,
			kind: saved.status === "skipped" ? "skip" : "reassign",
			...saved.familyId ? { familyId: saved.familyId } : {},
			...saved.note ? { note: saved.note } : {}
		}
	};
	return duty;
}
async function materializePastDuties(families, existingDuties, anchorDate) {
	const today = todayIST();
	const dayCount = Math.max(0, Math.min(2e4, Math.floor((Date.parse(`${today}T00:00:00Z`) - Date.parse(`${anchorDate}T00:00:00Z`)) / 864e5)));
	if (!dayCount) return;
	const scheduled = getSchedule(anchorDate, dayCount, makeRotationConfig(families, existingDuties, anchorDate), today);
	const stored = new Map(existingDuties.map((duty) => [duty.date, duty]));
	for (const duty of scheduled) {
		if (stored.has(duty.date)) continue;
		stored.set(duty.date, {
			date: duty.date,
			familyId: duty.family?.id ?? null,
			status: duty.status,
			note: duty.override?.note ?? ""
		});
	}
	const next = [...stored.values()];
	const { jsonStore } = await import("./store-Bz97We1e.mjs").then((n) => n.n).then((n) => n.n);
	await jsonStore.update("duties", () => next);
}
function publicDuty(duty) {
	return {
		...duty,
		family: duty.family ? stripPrivateFamilyFields(duty.family) : null,
		scheduledFamily: duty.scheduledFamily ? stripPrivateFamilyFields(duty.scheduledFamily) : null,
		override: duty.override ? {
			date: duty.override.date,
			kind: duty.override.kind,
			...duty.override.familyId ? { familyId: duty.override.familyId } : {},
			...duty.override.note ? { note: duty.override.note } : {}
		} : void 0
	};
}
function stripPrivateFamilyFields(family) {
	return {
		id: family.id,
		name: family.name,
		head: family.head,
		mohalla: family.mohalla,
		active: family.active,
		order: family.order
	};
}
async function enrollmentCodeHash(code) {
	const { createHash } = await import("node:crypto");
	return createHash("sha256").update(code.trim().toUpperCase()).digest("hex");
}
async function matchesEnrollmentCode(code, expectedHash) {
	const { timingSafeEqual } = await import("node:crypto");
	const actual = hexBytes(await enrollmentCodeHash(code));
	const expected = hexBytes(expectedHash);
	return actual.length === expected.length && timingSafeEqual(actual, expected);
}
function hexBytes(hex) {
	return Uint8Array.from(hex.match(/.{2}/g) ?? [], (byte) => Number.parseInt(byte, 16));
}
//#endregion
export { checkAdminSession_createServerFn_handler, createAnnouncement_createServerFn_handler, createFamily_createServerFn_handler, createFoodEntry_createServerFn_handler, exportAdminData_createServerFn_handler, getAdminSnapshot_createServerFn_handler, getPublicAnnouncements_createServerFn_handler, getPublicContributions_createServerFn_handler, getPublicDutyData_createServerFn_handler, getPublicHomeData_createServerFn_handler, getPublicPushConfig_createServerFn_handler, getPublicSchedule_createServerFn_handler, issueFamilyPushCode_createServerFn_handler, loginAdmin_createServerFn_handler, logoutAdmin_createServerFn_handler, recordContribution_createServerFn_handler, removeAnnouncement_createServerFn_handler, removeFamilyPushSubscription_createServerFn_handler, removeFoodEntry_createServerFn_handler, saveFamilyPayment_createServerFn_handler, setDuty_createServerFn_handler, subscribeFamilyPush_createServerFn_handler, updateAnnouncement_createServerFn_handler, updateAppSettings_createServerFn_handler, updateFamily_createServerFn_handler, updateFoodEntry_createServerFn_handler };

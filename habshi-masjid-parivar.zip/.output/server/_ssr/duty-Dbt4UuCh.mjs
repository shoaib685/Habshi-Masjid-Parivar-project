import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SectionTitle, r as PageHeader } from "./ui-B-mPjvYk.mjs";
import { b as CircleCheck, k as ArrowLeftRight, v as Clock } from "../_libs/lucide-react.mjs";
import { r as TodayDutyHero, t as DutyList } from "./DutyCards-D9C9fLdx.mjs";
import { t as Route } from "./duty-CIFumdY2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/duty-Dbt4UuCh.js
var import_jsx_runtime = require_jsx_runtime();
function DutyPage() {
	const { today, duty, yesterday, tomorrow, history } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Food duty",
			title: "Today's duty",
			description: "Families take turns in a fixed order. Inactive families are skipped automatically."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayDutyHero, { duty }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniCard, {
				label: "Yesterday",
				duty: yesterday
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniCard, {
				label: "Tomorrow",
				duty: tomorrow
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card mt-4 grid grid-cols-3 divide-x divide-border p-4 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-success" }),
					value: duty.family ? "Active" : "No duty",
					label: "Today's status"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-primary" }),
					value: "8:00 AM",
					label: "Daily reminder"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-4 text-gold-foreground" }),
					value: "Admin",
					label: "Swaps & changes"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Past 7 days" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyList, {
			days: history,
			today
		})
	] });
}
function MiniCard({ label, duty }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 line-clamp-2 font-display text-base font-semibold leading-snug text-foreground",
				children: duty.family ? duty.family.name : "No family duty"
			}),
			duty.family && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 truncate text-xs text-muted-foreground",
				children: duty.family.head
			})
		]
	});
}
function Fact({ icon, value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-lg font-semibold text-foreground",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] leading-tight text-muted-foreground",
				children: label
			})
		]
	});
}
//#endregion
export { DutyPage as component };

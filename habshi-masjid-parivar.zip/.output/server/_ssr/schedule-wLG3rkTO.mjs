import { f as getPublicSchedule } from "./admin-api-CHwB38Wv.mjs";
import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schedule-wLG3rkTO.js
var $$splitComponentImporter = () => import("./schedule-D2oXD-CJ.mjs");
var Route = createFileRoute("/schedule")({
	loader: () => getPublicSchedule(),
	head: () => ({ meta: [
		{ title: "Food Duty Schedule — Habshi Masjid Parivar" },
		{
			name: "description",
			content: "The upcoming daily food duty rotation for Habshi Masjid families, with swaps and changes marked."
		},
		{
			property: "og:title",
			content: "Food Duty Schedule — Habshi Masjid Parivar"
		},
		{
			property: "og:description",
			content: "Upcoming daily food duty rotation for Habshi Masjid families."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

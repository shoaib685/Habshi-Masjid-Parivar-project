import { n as __exportAll } from "../_runtime.mjs";
import { l as todayIST } from "./date-0gm0zi69.mjs";
import { l as ZodError } from "../_libs/zod.mjs";
import { a as emptyDatasets, r as datasetSchemas } from "./data-schemas-gms4ftdc.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { randomUUID } from "node:crypto";
import { dirname, join, resolve } from "node:path";
import { cwd, env } from "node:process";
import { copyFile, mkdir, open, readFile, readdir, rename, unlink } from "node:fs/promises";
//#region node_modules/.nitro/vite/services/ssr/assets/store-Bz97We1e.js
var store_Bz97We1e_exports = /* @__PURE__ */ __exportAll({
	n: () => store_exports,
	t: () => jsonStore
});
var store_exports = /* @__PURE__ */ __exportAll$1({
	createJsonStore: () => createJsonStore,
	jsonStore: () => jsonStore
});
var FILES = {
	families: "families.json",
	duties: "duties.json",
	food: "food.json",
	payments: "payments.json",
	contributions: "contributions.json",
	announcements: "announcements.json",
	notifications: "notifications.json",
	pushSubscriptions: "push-subscriptions.json",
	settings: "settings.json"
};
var BACKUP_LIMIT = 10;
function createJsonStore(root = resolve(cwd(), env["HMP_DATA_DIR"] ?? "data")) {
	let writeQueue = Promise.resolve();
	const serialize = (task) => {
		const result = writeQueue.then(task, task);
		writeQueue = result.then(() => void 0, () => void 0);
		return result;
	};
	const readFileData = async (name) => {
		const file = join(root, FILES[name]);
		try {
			const contents = await readFile(file, "utf8");
			return validateDataset(name, JSON.parse(contents));
		} catch (error) {
			if (isMissingFile(error)) {
				if (name === "settings") return {
					...emptyDatasets.settings,
					anchorDate: todayIST()
				};
				return structuredClone(emptyDatasets[name]);
			}
			if (error instanceof SyntaxError || error instanceof ZodError) throw new Error(`Stored ${FILES[name]} is invalid. Restore a backup before continuing.`, { cause: error });
			throw error;
		}
	};
	const read = (name) => writeQueue.then(() => readFileData(name));
	const update = (name, mutate) => serialize(async () => {
		const next = validateDataset(name, mutate(await readFileData(name)));
		const file = join(root, FILES[name]);
		await mkdir(dirname(file), {
			recursive: true,
			mode: 448
		});
		await backup(file, root);
		await atomicWrite(file, JSON.stringify(next, null, 2));
		return next;
	});
	const exportAll = async () => ({
		families: await read("families"),
		duties: await read("duties"),
		food: await read("food"),
		payments: await read("payments"),
		contributions: await read("contributions"),
		announcements: await read("announcements"),
		notifications: await read("notifications"),
		pushSubscriptions: await read("pushSubscriptions"),
		settings: await read("settings")
	});
	return {
		read,
		update,
		exportAll,
		root
	};
}
var jsonStore = createJsonStore();
function validateDataset(name, value) {
	const parsed = datasetSchemas[name].parse(value);
	if (!Array.isArray(parsed)) return parsed;
	const keys = parsed.map((item) => {
		if (item == null || typeof item !== "object") return "";
		if (name === "duties" && "date" in item) return String(item.date);
		if (name === "payments" && "familyId" in item && "month" in item) return `${item.familyId}:${item.month}`;
		if ("id" in item) return String(item.id);
		return "";
	});
	if (new Set(keys).size !== keys.length) throw new Error(`Stored ${FILES[name]} contains duplicate records.`);
	return parsed;
}
function isMissingFile(error) {
	return error != null && typeof error === "object" && "code" in error && error.code === "ENOENT";
}
async function backup(file, root) {
	try {
		await readFile(file);
	} catch (error) {
		if (isMissingFile(error)) return;
		throw error;
	}
	const backupDir = join(root, "backups");
	await mkdir(backupDir, {
		recursive: true,
		mode: 448
	});
	const sourceName = file.slice(root.length + 1);
	await copyFile(file, join(backupDir, `${sourceName}.${(/* @__PURE__ */ new Date()).toISOString().replaceAll(":", "-")}.${randomUUID()}.bak`));
	const backups = (await readdir(backupDir)).filter((name) => name.startsWith(`${sourceName}.`)).sort().reverse();
	await Promise.all(backups.slice(BACKUP_LIMIT).map((name) => unlink(join(backupDir, name))));
}
async function atomicWrite(file, contents) {
	const temporary = `${file}.${randomUUID()}.tmp`;
	let handle;
	try {
		handle = await open(temporary, "wx", 384);
		await handle.writeFile(contents, "utf8");
		await handle.sync();
		await handle.close();
		handle = void 0;
		await rename(temporary, file);
	} catch (error) {
		await handle?.close();
		await unlink(temporary).catch(() => void 0);
		throw error;
	}
}
//#endregion
export { store_Bz97We1e_exports as n, jsonStore as t };

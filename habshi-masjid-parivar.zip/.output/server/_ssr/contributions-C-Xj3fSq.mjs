import { c as getPublicContributions } from "./admin-api-CHwB38Wv.mjs";
import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contributions-C-Xj3fSq.js
var $$splitComponentImporter = () => import("./contributions-ooox4U6h.mjs");
var Route = createFileRoute("/contributions")({
	loader: () => getPublicContributions(),
	head: () => ({ meta: [
		{ title: "Contribution Summary — Habshi Masjid Parivar" },
		{
			name: "description",
			content: "Voluntary contribution totals for the Habshi Masjid community."
		},
		{
			property: "og:title",
			content: "Contribution Summary — Habshi Masjid Parivar"
		},
		{
			property: "og:description",
			content: "Monthly contribution totals for the Habshi Masjid community."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

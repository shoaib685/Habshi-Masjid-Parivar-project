import { i as __toESM } from "../_runtime.mjs";
import { m as loginAdmin } from "./admin-api-CHwB38Wv.mjs";
import { c as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { f as Link, p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as ArrowLeft, f as LockKeyhole } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-DX_6BsEM.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin_.login-CQLxE_Ig.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLogin() {
	const navigate = useNavigate();
	const [code, setCode] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const submit = async (e) => {
		e.preventDefault();
		if (!code) return;
		setBusy(true);
		try {
			await loginAdmin({ data: { password: code } });
			await navigate({ to: "/admin" });
		} catch {
			toast.error("Sign-in failed", { description: "Check the passcode or try again later." });
		} finally {
			setBusy(false);
			setCode("");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/settings",
				className: "mb-6 inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Settings"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-hero animate-rise px-6 pb-14 pt-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid size-16 place-items-center rounded-2xl bg-primary-foreground/12 ring-1 ring-primary-foreground/25",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { className: "size-7 text-gold" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-3xl font-semibold",
						children: "Admin access"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-2 max-w-xs text-sm text-primary-foreground/80",
						children: "Enter the administrator password to securely manage community records."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "surface-card relative mx-2 -mt-8 p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "admin-password",
						className: "mb-2 block text-sm font-semibold text-foreground",
						children: "Admin password"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "admin-password",
						type: "password",
						autoComplete: "current-password",
						value: code,
						onChange: (event) => setCode(event.target.value),
						required: true,
						autoFocus: true,
						className: "h-12 rounded-xl"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "hero",
						size: "lg",
						className: "mt-6 w-full",
						disabled: !code || busy,
						children: busy ? "Checking…" : "Sign in"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-center text-xs text-muted-foreground",
						children: "Only the masjid administrator signs in. Families don't need accounts."
					})
				]
			})
		]
	});
}
//#endregion
export { AdminLogin as component };

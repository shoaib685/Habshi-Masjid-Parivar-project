//#region node_modules/.nitro/vite/services/ssr/assets/date-0gm0zi69.js
var APP_TIMEZONE = "Asia/Kolkata";
/** Today's calendar date in IST as YYYY-MM-DD. */
function todayIST(now = /* @__PURE__ */ new Date()) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: APP_TIMEZONE,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(now);
}
function parts(iso) {
	const [y = 1970, m = 1, d = 1] = iso.split("-").map(Number);
	return [
		y,
		m,
		d
	];
}
function toUtc(iso) {
	const [y, m, d] = parts(iso);
	return Date.UTC(y, m - 1, d);
}
function addDays(iso, days) {
	return new Date(toUtc(iso) + days * 864e5).toISOString().slice(0, 10);
}
function daysBetween(fromIso, toIso) {
	return Math.round((toUtc(toIso) - toUtc(fromIso)) / 864e5);
}
function formatDate(iso, options) {
	return new Intl.DateTimeFormat("en-IN", {
		timeZone: "UTC",
		...options
	}).format(/* @__PURE__ */ new Date(`${iso}T00:00:00Z`));
}
function formatMonth(monthKey, style = "long") {
	return formatDate(`${monthKey}-01`, {
		month: style,
		year: "numeric"
	});
}
function monthKeyOf(iso) {
	return iso.slice(0, 7);
}
function shiftMonth(monthKey, delta) {
	const [y, m] = parts(`${monthKey}-01`);
	return new Date(Date.UTC(y, m - 1 + delta, 1)).toISOString().slice(0, 7);
}
function relativeDayLabel(iso, today) {
	const diff = daysBetween(today, iso);
	if (diff === 0) return "Today";
	if (diff === 1) return "Tomorrow";
	if (diff === -1) return "Yesterday";
	return formatDate(iso, { weekday: "long" });
}
//#endregion
export { formatMonth as a, shiftMonth as c, formatDate as i, todayIST as l, addDays as n, monthKeyOf as o, daysBetween as r, relativeDayLabel as s, APP_TIMEZONE as t };

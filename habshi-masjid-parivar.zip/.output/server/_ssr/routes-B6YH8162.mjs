import { n as formatINR } from "./contributions-Cg-XokK7.mjs";
import { a as formatMonth } from "./date-0gm0zi69.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SectionTitle, i as Pill } from "./ui-B-mPjvYk.mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Megaphone, s as Pin, t as UtensilsCrossed } from "../_libs/lucide-react.mjs";
import { n as SeeAllLink, r as TodayDutyHero, t as DutyList } from "./DutyCards-D9C9fLdx.mjs";
import { t as Route } from "./routes-BgNElvcv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B6YH8162.js
var import_jsx_runtime = require_jsx_runtime();
function greeting() {
	const hour = Number(new Intl.DateTimeFormat("en-IN", {
		hour: "numeric",
		hour12: false,
		timeZone: "Asia/Kolkata"
	}).format(/* @__PURE__ */ new Date()));
	if (hour < 12) return "Good morning";
	if (hour < 17) return "Good afternoon";
	return "Good evening";
}
function Home() {
	const { today, duty, schedule: upcoming, food, month, summary, announcement: latest } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "lg:grid lg:grid-cols-[1.25fr_1fr] lg:gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "animate-rise mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-arabic text-2xl leading-relaxed text-primary",
					dir: "rtl",
					lang: "ar",
					children: "بِسْمِ ٱللَّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-[1.75rem] font-semibold text-foreground lg:text-4xl",
						suppressHydrationWarning: true,
						children: greeting()
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayDutyHero, {
				duty,
				showDate: false,
				showReminder: false
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Today's food" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "surface-card p-5",
				"aria-live": "polite",
				children: food.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-4",
					children: food.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 shrink-0 place-items-center rounded-xl bg-gold-soft text-gold-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold text-foreground",
								children: item.title
							}), item.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 whitespace-pre-line text-sm text-muted-foreground",
								children: item.description
							})]
						})]
					}, item.id))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 shrink-0 place-items-center rounded-xl bg-muted text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-foreground",
						children: "Menu not announced yet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Today's food information will appear here when it is available."
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeeAllLink, { to: "/schedule" }),
				children: "Coming up"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyList, {
				days: upcoming,
				today
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, {
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeeAllLink, {
					to: "/contributions",
					label: "Details"
				}),
				children: [formatMonth(month, "long"), " contributions"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/contributions",
				className: "surface-card block p-5 transition-transform active:scale-[0.99]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-end justify-between",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-muted-foreground",
						children: "Collected so far"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold text-foreground",
						children: formatINR(summary.collected)
					})] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-3 gap-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Records",
							value: summary.entries,
							tone: "text-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Cash",
							value: formatINR(summary.cash),
							tone: "text-foreground"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "UPI",
							value: formatINR(summary.upi),
							tone: "text-foreground"
						})
					]
				})]
			}),
			latest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeeAllLink, { to: "/announcements" }),
				children: "Latest notice"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/announcements",
				className: "surface-card block p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-8 place-items-center rounded-full bg-gold-soft text-gold-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
								tone: "gold",
								children: latest.tag
							}),
							latest.pinned && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "ml-auto size-4 text-muted-foreground" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 text-lg font-semibold text-foreground",
						children: latest.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-3 text-sm text-muted-foreground",
						children: latest.body
					})
				]
			})] })
		] })]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-muted px-2 py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `font-display text-xl font-semibold ${tone}`,
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium text-muted-foreground",
			children: label
		})]
	});
}
//#endregion
export { Home as component };

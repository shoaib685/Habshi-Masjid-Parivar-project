import { i as __toESM } from "../_runtime.mjs";
import { n as formatINR, t as contributionStatus } from "./contributions-Cg-XokK7.mjs";
import { a as formatMonth, c as shiftMonth, i as formatDate } from "./date-0gm0zi69.mjs";
import { i as reminderTimeToParts, r as reminderTimeFromParts, t as formatReminderTime } from "./reminder-time-JjPPV1YP.mjs";
import { C as updateAnnouncement, E as updateFoodEntry, T as updateFamily, _ as removeAnnouncement, a as exportAdminData, b as saveFamilyPayment, g as recordContribution, h as logoutAdmin, i as createFoodEntry, n as createAnnouncement, o as getAdminSnapshot, p as issueFamilyPushCode, r as createFamily, t as checkAdminSession, w as updateAppSettings, x as setDuty, y as removeFoodEntry } from "./admin-api-CHwB38Wv.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SectionTitle, i as Pill, n as FamilyAvatar, r as PageHeader } from "./ui-B-mPjvYk.mjs";
import { p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as Check, T as Bell, _ as Download, g as FileText, h as HandCoins, n as Users, t as UtensilsCrossed, u as LogOut, x as ChevronRight, y as CircleDollarSign } from "../_libs/lucide-react.mjs";
import { t as DutyList } from "./DutyCards-D9C9fLdx.mjs";
import { t as Button } from "./button-DX_6BsEM.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-ClplAPlb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function summarizeFamilyPayments(month, families, payments) {
	const monthPayments = new Map(payments.filter((payment) => payment.month === month).map((payment) => [payment.familyId, payment]));
	const summary = {
		expected: 0,
		collected: 0,
		outstanding: 0,
		paid: 0,
		partial: 0,
		pending: 0
	};
	for (const family of families) {
		const payment = monthPayments.get(family.id);
		const due = payment?.amountDue ?? family.monthlyFee;
		const received = payment?.amountReceived ?? 0;
		summary.expected += due;
		summary.collected += received;
		summary.outstanding += Math.max(0, due - received);
		if (received >= due) summary.paid += 1;
		else if (received > 0) summary.partial += 1;
		else summary.pending += 1;
	}
	return summary;
}
var TABS = [
	"Overview",
	"Families",
	"Food",
	"Duties",
	"Payments",
	"Contributions",
	"Announcements",
	"Notifications",
	"Settings"
];
function AdminDashboard() {
	const navigate = useNavigate();
	const [snapshot, setSnapshot] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("Overview");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [search, setSearch] = (0, import_react.useState)("");
	const refresh = (0, import_react.useCallback)(async () => {
		const data = await getAdminSnapshot();
		setSnapshot(data);
	}, []);
	(0, import_react.useEffect)(() => {
		let active = true;
		const open = async () => {
			try {
				const session = await checkAdminSession();
				if (!active) return;
				if (!session.authenticated) {
					await navigate({
						to: "/admin/login",
						replace: true
					});
					return;
				}
				await refresh();
			} catch {
				if (active) await navigate({
					to: "/admin/login",
					replace: true
				});
			} finally {
				if (active) setLoading(false);
			}
		};
		open();
		return () => {
			active = false;
		};
	}, [navigate, refresh]);
	const run = async (action, success) => {
		try {
			await action();
			await refresh();
			toast.success(success);
			return true;
		} catch (error) {
			toast.error("Could not save changes", { description: error instanceof Error ? error.message : "Please try again." });
			return false;
		}
	};
	const signOut = async () => {
		try {
			await logoutAdmin();
			await navigate({ to: "/settings" });
		} catch {
			toast.error("Could not sign out. Please try again.");
		}
	};
	if (loading || !snapshot) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted-foreground",
		children: "Opening secure admin dashboard…"
	});
	const activeFamilies = snapshot.families.filter((family) => family.active);
	const todayDuty = snapshot.schedule.find((duty) => duty.date === snapshot.today);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Administration",
			title: "Admin dashboard",
			description: formatDate(snapshot.today, {
				weekday: "long",
				day: "numeric",
				month: "long"
			}),
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				onClick: signOut,
				"aria-label": "Sign out",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: "Sign out"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex gap-2 overflow-x-auto pb-1 scrollbar-none",
			role: "tablist",
			"aria-label": "Admin sections",
			children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				id: `admin-tab-${item.toLowerCase()}`,
				role: "tab",
				"aria-selected": tab === item,
				"aria-controls": "admin-tab-panel",
				onClick: () => setTab(item),
				className: `shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition-colors ${tab === item ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:text-foreground"}`,
				children: item
			}, item))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			id: "admin-tab-panel",
			role: "tabpanel",
			"aria-labelledby": `admin-tab-${tab.toLowerCase()}`,
			children: [
				tab === "Overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, {
					snapshot,
					activeFamilies,
					todayFamily: todayDuty?.family?.name ?? "No family duty",
					setTab
				}),
				tab === "Families" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamiliesPanel, {
					families: snapshot.families,
					search,
					setSearch,
					run
				}),
				tab === "Food" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodPanel, {
					foods: snapshot.foods,
					run
				}),
				tab === "Duties" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutiesPanel, {
					families: activeFamilies,
					schedule: snapshot.schedule,
					today: snapshot.today,
					run
				}),
				tab === "Payments" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentsPanel, {
					families: snapshot.families,
					payments: snapshot.payments,
					month: snapshot.month,
					run
				}),
				tab === "Contributions" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContributionsPanel, {
					families: snapshot.families,
					contributions: snapshot.contributions,
					month: snapshot.month,
					today: snapshot.today,
					run
				}),
				tab === "Announcements" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnnouncementsPanel, {
					announcements: snapshot.announcements,
					today: snapshot.today,
					run
				}),
				tab === "Notifications" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationsPanel, {
					notifications: snapshot.notifications,
					families: snapshot.families
				}),
				tab === "Settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {
					snapshot,
					run
				})
			]
		})
	] });
}
function Overview({ snapshot, activeFamilies, todayFamily, setTab }) {
	const paymentSummary = summarizeFamilyPayments(snapshot.month, snapshot.families, snapshot.payments);
	const recent = snapshot.payments.flatMap((payment) => payment.history.map((change) => ({
		id: change.id,
		label: `Payment updated for ${snapshot.families.find((family) => family.id === payment.familyId)?.name ?? payment.familyId}`,
		time: change.at
	}))).sort((a, b) => b.time.localeCompare(a.time)).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start gap-3 rounded-2xl bg-primary-soft p-4 text-sm text-accent-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Records are stored on this server. Keep the configured data directory on persistent storage and back it up regularly." })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {}),
					label: "Active families",
					value: String(activeFamilies.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, {}),
					label: "Today's duty",
					value: todayFamily
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleDollarSign, {}),
					label: "Voluntary contributions",
					value: formatINR(snapshot.contributionSummary.collected)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandCoins, {}),
					label: "Outstanding dues",
					value: formatINR(paymentSummary.outstanding)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Monthly family payments" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniMetric, {
					label: "Done",
					value: paymentSummary.paid
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniMetric, {
					label: "Partially paid",
					value: paymentSummary.partial
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniMetric, {
					label: "Pending",
					value: paymentSummary.pending
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setTab("Duties"),
				className: "text-sm font-semibold text-primary",
				children: ["Manage ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "inline size-4" })]
			}),
			children: "Upcoming food duty"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyList, {
			days: snapshot.schedule.filter((day) => day.date >= snapshot.today).slice(0, 5),
			today: snapshot.today
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Manage community" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {}),
					title: "Families",
					detail: `${snapshot.families.length} family records`,
					onClick: () => setTab("Families")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, {}),
					title: "Food",
					detail: `${snapshot.foods.length} food arrangements`,
					onClick: () => setTab("Food")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandCoins, {}),
					title: "Payments",
					detail: "Private mandatory payment ledger",
					onClick: () => setTab("Payments")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}),
					title: "Contributions",
					detail: "Separate voluntary records",
					onClick: () => setTab("Contributions")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Recent payment updates" }),
		recent.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "surface-card divide-y divide-border",
			children: recent.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 truncate text-foreground",
					children: item.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-xs text-muted-foreground",
					children: formatDate(item.time.slice(0, 10), {
						day: "numeric",
						month: "short"
					})
				})]
			}, item.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-4 text-sm text-muted-foreground",
			children: "No admin changes recorded yet."
		})
	] });
}
function FamiliesPanel({ families, search, setSearch, run }) {
	const matches = families.filter((family) => `${family.id} ${family.name}`.toLowerCase().includes(search.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Community",
			title: "Family management",
			description: "Family IDs are permanent. Deactivate rather than delete a family."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyEditor, { onSave: (values) => run(() => createFamily({ data: values }), "Family added") }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			"aria-label": "Search families by ID or name",
			placeholder: "Search by Family ID or name",
			value: search,
			onChange: (event) => setSearch(event.target.value),
			className: "mb-3 h-11 rounded-xl bg-card"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card divide-y divide-border overflow-hidden",
			children: [matches.map((family) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyRow, {
				family,
				run
			}, family.id)), !matches.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-5 text-sm text-muted-foreground",
				children: "No matching families."
			})]
		})
	] });
}
function FamilyEditor({ family, onSave }) {
	const [open, setOpen] = (0, import_react.useState)(!!family);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const submit = async (event) => {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		const formElement = event.currentTarget;
		const values = {
			name: String(form.get("name") ?? ""),
			head: String(form.get("head") ?? ""),
			contactNumber: String(form.get("contactNumber") ?? ""),
			members: Number(form.get("members") ?? 1),
			mohalla: String(form.get("mohalla") ?? ""),
			active: form.get("active") === "on",
			order: Number(form.get("order") ?? family?.order ?? 1),
			monthlyFee: Number(form.get("monthlyFee") ?? 0)
		};
		setBusy(true);
		const saved = await onSave(values);
		setBusy(false);
		if (saved && !family) formElement.reset();
		if (saved && !family) setOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		open,
		onToggle: (event) => setOpen(event.currentTarget.open),
		className: "surface-card mb-4 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: "cursor-pointer font-semibold text-foreground",
			children: family ? `Edit ${family.id}` : "Add a family"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Family name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "name",
						required: true,
						maxLength: 120,
						defaultValue: family?.name
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Primary contact number",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "contactNumber",
						type: "tel",
						inputMode: "tel",
						required: true,
						defaultValue: family?.contactNumber
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Family head (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "head",
						maxLength: 120,
						defaultValue: family?.head
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mohalla (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "mohalla",
						maxLength: 100,
						defaultValue: family?.mohalla
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Monthly family payment amount (₹)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "monthlyFee",
						type: "number",
						min: "0",
						max: "1000000",
						step: "1",
						required: true,
						defaultValue: family?.monthlyFee ?? 0
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Member count (private admin field)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "members",
						type: "number",
						min: "1",
						max: "100",
						step: "1",
						required: true,
						defaultValue: family?.members ?? 1
					})
				}),
				family && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Rotation order",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "order",
						type: "number",
						min: "1",
						step: "1",
						required: true,
						defaultValue: family.order
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "active",
						type: "checkbox",
						defaultChecked: family?.active ?? true
					}), "Active in rotation"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						children: busy ? "Saving…" : family ? "Save family" : "Add family"
					}), family && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => setOpen(false),
						children: "Close"
					})]
				})
			]
		})]
	});
}
function FamilyRow({ family, run }) {
	const [registrationCode, setRegistrationCode] = (0, import_react.useState)("");
	const update = (values) => run(() => updateFamily({ data: {
		...values,
		id: family.id,
		order: values.order
	} }), "Family updated");
	const { order: _order, ...editable } = family;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyAvatar, {
					name: family.name,
					size: "sm",
					tone: family.active ? "primary" : "muted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold text-foreground",
						children: family.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted-foreground",
						children: [
							family.id,
							" · ",
							family.contactNumber
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
					tone: family.active ? "success" : "muted",
					children: family.active ? "Active" : "Inactive"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
			className: "mt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
				className: "cursor-pointer text-xs font-semibold text-primary",
				children: "Edit details"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 rounded-xl bg-muted p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-foreground",
							children: "Push notification setup"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: "Generate a code and share it with this family to register their devices."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: async () => {
									try {
										const result = await issueFamilyPushCode({ data: { familyId: family.id } });
										setRegistrationCode(result.code);
										toast.success("New family setup code generated.");
									} catch (error) {
										toast.error("Could not generate setup code", { description: error instanceof Error ? error.message : "Please try again." });
									}
								},
								children: "Generate setup code"
							}), registrationCode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "rounded bg-background px-2 py-1 text-sm font-bold tracking-wider",
								children: registrationCode
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyEditor, {
					family: {
						...editable,
						order: family.order
					},
					onSave: update
				}, `${family.id}-${family.order}`)]
			})]
		})]
	});
}
function FoodPanel({ foods, run }) {
	const [editing, setEditing] = (0, import_react.useState)();
	const submit = async (event) => {
		event.preventDefault();
		const formElement = event.currentTarget;
		const form = new FormData(formElement);
		const entry = {
			date: String(form.get("date") ?? ""),
			title: String(form.get("title") ?? ""),
			description: String(form.get("description") ?? "")
		};
		if (!await run(editing ? () => updateFoodEntry({ data: {
			...entry,
			id: editing.id
		} }) : () => createFoodEntry({ data: entry }), editing ? "Food arrangement updated" : "Food arrangement added")) return;
		setEditing(void 0);
		formElement.reset();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Food",
			title: "Food management",
			description: "Add today's arrangements; public pages only show the date and menu description."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "surface-card mb-4 space-y-3 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "date",
						type: "date",
						required: true,
						defaultValue: editing?.date
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Food arrangement",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true,
						maxLength: 120,
						defaultValue: editing?.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Details",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						name: "description",
						maxLength: 1e3,
						defaultValue: editing?.description
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: editing ? "Save changes" : "Add food"
					}), editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => setEditing(void 0),
						children: "Cancel edit"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [foods.map((food) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "surface-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "mt-1 size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground",
								children: food.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: formatDate(food.date, {
									day: "numeric",
									month: "long",
									year: "numeric"
								})
							}),
							food.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: food.description
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setEditing(food),
						children: "Edit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void run(() => removeFoodEntry({ data: { id: food.id } }), "Food entry removed"),
						children: "Delete"
					})]
				})]
			}, food.id)), !foods.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "surface-card p-5 text-sm text-muted-foreground",
				children: "No food arrangements yet."
			})]
		})
	] });
}
function DutiesPanel({ families, schedule, today, run }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Food rotation",
		title: "Duty history & schedule",
		description: "The daily rotation excludes inactive families. Manual changes are saved by date."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: schedule.map((duty) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-foreground",
					children: formatDate(duty.date, {
						weekday: "short",
						day: "numeric",
						month: "short"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: duty.family?.name ?? duty.override?.note ?? "No family duty"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
					tone: duty.status === "completed" ? "success" : duty.status === "overridden" ? "gold" : duty.status === "skipped" ? "muted" : "primary",
					children: duty.status
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-xs font-semibold text-primary",
					children: duty.date < today ? "Correct history" : "Change assignment"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						const form = new FormData(event.currentTarget);
						const familyId = String(form.get("familyId") ?? "");
						const note = String(form.get("note") ?? "");
						const skipped = !familyId;
						run(() => setDuty({ data: {
							date: duty.date,
							familyId: skipped ? null : familyId,
							status: skipped ? "skipped" : "overridden",
							note
						} }), "Duty assignment saved");
					},
					className: "mt-3 grid gap-2 sm:grid-cols-[1fr_1fr_auto]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							name: "familyId",
							defaultValue: duty.family?.id ?? "",
							className: "h-10 rounded-lg border border-input bg-background px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Skip / no duty"
							}), families.map((family) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: family.id,
								children: [
									family.id,
									" · ",
									family.name
								]
							}, family.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "note",
							maxLength: 500,
							placeholder: "Optional reason",
							defaultValue: duty.override?.note
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							children: "Save"
						})
					]
				}),
				duty.family && duty.status !== "completed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					className: "mt-2",
					onClick: () => void run(() => setDuty({ data: {
						date: duty.date,
						familyId: duty.family.id,
						status: "completed",
						note: ""
					} }), "Duty marked completed"),
					children: "Mark completed"
				})
			] })]
		}, duty.date))
	})] });
}
function PaymentsPanel({ families, payments, month, run }) {
	const months = Array.from({ length: 6 }, (_, index) => shiftMonth(month, index - 5)).reverse();
	const [selectedMonth, setSelectedMonth] = (0, import_react.useState)(month);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const paymentSummary = summarizeFamilyPayments(selectedMonth, families, payments);
	const rows = families.map((family) => {
		const payment = payments.find((item) => item.familyId === family.id && item.month === selectedMonth);
		const due = payment?.amountDue ?? family.monthlyFee;
		const received = payment?.amountReceived ?? 0;
		return {
			family,
			payment,
			due,
			received,
			status: contributionStatus(due, received)
		};
	}).filter((row) => filter === "all" || row.status === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Private admin ledger",
			title: "Mandatory family payments",
			description: "Record cash or UPI payments here. This ledger is separate from voluntary contributions."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				"aria-label": "Payment month",
				value: selectedMonth,
				onChange: (event) => setSelectedMonth(event.target.value),
				className: "h-10 rounded-lg border border-input bg-background px-3 text-sm",
				children: months.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: item,
					children: formatMonth(item)
				}, item))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				"aria-label": "Filter payment status",
				value: filter,
				onChange: (event) => setFilter(event.target.value),
				className: "h-10 rounded-lg border border-input bg-background px-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "All statuses"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "paid",
						children: "Done"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "partial",
						children: "Partially paid"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "pending",
						children: "Pending"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeMetric, {
					label: "Expected",
					value: paymentSummary.expected
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeMetric, {
					label: "Collected",
					value: paymentSummary.collected
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeMetric, {
					label: "Outstanding",
					value: paymentSummary.outstanding
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [rows.map(({ family, payment, due, received, status }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentEditor, {
				family,
				month: selectedMonth,
				due,
				received,
				status,
				history: payment?.history ?? [],
				run
			}, `${family.id}-${selectedMonth}`)), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "surface-card p-5 text-sm text-muted-foreground",
				children: "No payments match this status."
			})]
		})
	] });
}
function PaymentEditor({ family, month, due, received, status, history, run }) {
	const statusLabel = status === "paid" ? "Done" : status === "partial" ? "Partially Paid" : "Pending";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "surface-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
				className: "flex cursor-pointer list-none items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold text-foreground",
						children: family.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							family.id,
							" · ",
							formatINR(received),
							" of ",
							formatINR(due)
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
					tone: status === "paid" ? "success" : status === "partial" ? "warning" : "pending",
					children: statusLabel
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 space-y-3",
				onSubmit: async (event) => {
					event.preventDefault();
					const formElement = event.currentTarget;
					const form = new FormData(formElement);
					const amountDue = Number(form.get("amountDue"));
					const amountPaid = Number(form.get("amountPaid"));
					const method = form.get("method");
					if (method !== "cash" && method !== "upi") {
						toast.error("Choose a payment method.");
						return;
					}
					const note = String(form.get("note") ?? "");
					if (await run(() => saveFamilyPayment({ data: {
						familyId: family.id,
						month,
						amountDue,
						amountPaid,
						method,
						note
					} }), "Payment recorded")) formElement.reset();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Amount due (₹)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "amountDue",
									type: "number",
									min: "0",
									max: "1000000",
									step: "1",
									required: true,
									defaultValue: due
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "New payment amount (₹)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									name: "amountPaid",
									type: "number",
									min: "0",
									max: "1000000",
									step: "1",
									required: true,
									defaultValue: "0"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Payment method",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									name: "method",
									defaultValue: "cash",
									className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "cash",
										children: "Cash"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "upi",
										children: "UPI"
									})]
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-muted-foreground",
						children: [
							"Received so far: ",
							formatINR(received),
							" · Remaining:",
							" ",
							formatINR(Math.max(0, due - received))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Admin note",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "note",
							maxLength: 300,
							placeholder: "Optional history note"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "sm",
						children: "Record payment"
					})
				]
			}),
			!!history.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 border-t border-border pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs font-semibold text-muted-foreground",
					children: "Payment history"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1 text-xs text-muted-foreground",
					children: [...history].reverse().map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						formatDate(entry.at.slice(0, 10), {
							day: "numeric",
							month: "short"
						}),
						":",
						" ",
						"amount" in entry ? `${formatINR(entry.amount)} by ${entry.method.toUpperCase()}` : `received ${formatINR(entry.amountReceived)} / due ${formatINR(entry.amountDue)}`,
						entry.note ? ` · ${entry.note}` : ""
					] }, entry.id))
				})]
			})
		]
	});
}
function ContributionsPanel({ families, contributions, month, today, run }) {
	const [selectedMonth, setSelectedMonth] = (0, import_react.useState)(month);
	const currentRecords = contributions.filter((entry) => entry.month === selectedMonth);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Separate voluntary ledger",
			title: "Contributions",
			description: "Manual records only; not merged with mandatory family payment balances."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "surface-card mb-4 grid gap-3 p-4 sm:grid-cols-2",
			onSubmit: async (event) => {
				event.preventDefault();
				const formElement = event.currentTarget;
				const form = new FormData(formElement);
				if (await run(() => recordContribution({ data: {
					familyId: String(form.get("familyId") ?? ""),
					month: String(form.get("month") ?? ""),
					amount: Number(form.get("amount")),
					method: form.get("method") === "upi" ? "upi" : "cash",
					paidOn: String(form.get("paidOn") ?? ""),
					note: String(form.get("note") ?? "")
				} }), "Contribution recorded")) formElement.reset();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Family",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						name: "familyId",
						required: true,
						className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Choose family"
						}), families.map((family) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: family.id,
							children: [
								family.id,
								" · ",
								family.name
							]
						}, family.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Month",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "month",
						type: "month",
						required: true,
						defaultValue: month
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Amount (₹)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "amount",
						type: "number",
						min: "1",
						max: "1000000",
						step: "1",
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Manual method",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						name: "method",
						className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "cash",
							children: "Cash"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "upi",
							children: "UPI transfer recorded manually"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Received date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "paidOn",
						type: "date",
						required: true,
						defaultValue: today
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Note (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "note",
						maxLength: 300
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "sm:col-span-2",
					children: "Record contribution"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mb-3 block text-sm font-semibold text-foreground",
			children: ["View month", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				value: selectedMonth,
				onChange: (event) => setSelectedMonth(event.target.value),
				className: "mt-1 block h-10 w-full rounded-lg border border-input bg-background px-3",
				children: Array.from({ length: 12 }, (_, index) => shiftMonth(month, index - 11)).reverse().map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: item,
					children: formatMonth(item)
				}, item))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card divide-y divide-border",
			children: [currentRecords.map((record) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 p-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-semibold text-foreground",
						children: families.find((family) => family.id === record.familyId)?.name ?? record.familyId
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							record.paidOn,
							" · ",
							record.method.toUpperCase(),
							record.note ? ` · ${record.note}` : ""
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold text-foreground",
					children: formatINR(record.amount)
				})]
			}, record.id)), !currentRecords.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-5 text-sm text-muted-foreground",
				children: "No contributions recorded for this month."
			})]
		})
	] });
}
function AnnouncementsPanel({ announcements, today, run }) {
	const [editing, setEditing] = (0, import_react.useState)();
	const submit = async (event) => {
		event.preventDefault();
		const formElement = event.currentTarget;
		const form = new FormData(formElement);
		const rawTag = String(form.get("tag") ?? "");
		const values = {
			title: String(form.get("title") ?? ""),
			body: String(form.get("body") ?? ""),
			date: String(form.get("date") ?? ""),
			tag: rawTag === "Event" || rawTag === "Reminder" ? rawTag : "Notice",
			pinned: form.get("pinned") === "on"
		};
		if (!await run(editing ? () => updateAnnouncement({ data: {
			...values,
			id: editing.id
		} }) : () => createAnnouncement({ data: values }), editing ? "Announcement updated" : "Announcement published")) return;
		setEditing(void 0);
		formElement.reset();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Public updates",
			title: "Announcements",
			description: "Published notices appear on the public announcements page."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "surface-card mb-4 space-y-3 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Title",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true,
						maxLength: 160,
						defaultValue: editing?.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Message",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						name: "body",
						required: true,
						maxLength: 3e3,
						defaultValue: editing?.body
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "date",
							type: "date",
							required: true,
							defaultValue: editing?.date ?? today
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Type",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							name: "tag",
							defaultValue: editing?.tag ?? "Notice",
							className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Notice" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Event" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Reminder" })
							]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "pinned",
						type: "checkbox",
						defaultChecked: editing?.pinned
					}), " Pin announcement"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: editing ? "Save announcement" : "Publish announcement"
					}), editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => setEditing(void 0),
						children: "Cancel"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: announcements.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "surface-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold text-primary",
						children: [
							item.tag,
							" · ",
							item.date,
							item.pinned ? " · Pinned" : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-semibold text-foreground",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: item.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setEditing(item),
							children: "Edit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => void run(() => removeAnnouncement({ data: { id: item.id } }), "Announcement removed"),
							children: "Delete"
						})]
					})
				]
			}, item.id))
		})
	] });
}
function NotificationsPanel({ notifications, families }) {
	const [dateFilter, setDateFilter] = (0, import_react.useState)("");
	const [familyFilter, setFamilyFilter] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const visible = [...notifications].filter((item) => !dateFilter || item.dutyDate === dateFilter).filter((item) => !familyFilter || item.familyId === familyFilter).filter((item) => statusFilter === "all" || item.status === statusFilter).sort((a, b) => b.dutyDate.localeCompare(a.dutyDate) || b.createdAt.localeCompare(a.createdAt));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Delivery status",
			title: "Notifications",
			description: "Private delivery history for family-specific duty reminders."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start gap-3 rounded-2xl border border-warning/30 bg-warning-soft p-4 text-sm text-warning",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A “not configured” status means that provider credentials or push subscriptions are missing. “Accepted” means the provider accepted the request, not that a device displayed it. “Queued” records are not retried automatically, to avoid duplicate reminders." })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 grid gap-2 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Duty date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: dateFilter,
						onChange: (event) => setDateFilter(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Family",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: familyFilter,
						onChange: (event) => setFamilyFilter(event.target.value),
						className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All families"
						}), families.map((family) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: family.id,
							children: [
								family.id,
								" · ",
								family.name
							]
						}, family.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Delivery status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: statusFilter,
						onChange: (event) => setStatusFilter(event.target.value),
						className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All statuses"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "sent",
								children: "Accepted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "failed",
								children: "Failed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "not-configured",
								children: "Not configured"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "queued",
								children: "Queued"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "skipped",
								children: "Skipped"
							})
						]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card divide-y divide-border",
			children: [visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 p-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold text-foreground",
							children: [
								item.familyId,
								" ·",
								" ",
								families.find((family) => family.id === item.familyId)?.name ?? "Unknown family"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Duty ",
								item.dutyDate,
								" · Scheduled ",
								formatReminderTime(item.scheduledTime)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								item.channel.toUpperCase(),
								" ·",
								" ",
								item.deliveredAt ? `Accepted ${formatTimestamp(item.deliveredAt)}` : `Attempted ${formatTimestamp(item.createdAt)}`,
								item.detail ? ` · ${item.detail}` : ""
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
					tone: item.status === "sent" ? "success" : item.status === "skipped" ? "muted" : item.status === "failed" ? "pending" : "warning",
					children: item.status === "sent" ? "Accepted" : item.status
				})]
			}, item.id)), !visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-5 text-sm text-muted-foreground",
				children: "No notification delivery records match these filters."
			})]
		})
	] });
}
function SettingsPanel({ snapshot, run }) {
	const [reminderParts, setReminderParts] = (0, import_react.useState)(() => reminderTimeToParts(snapshot.settings.reminderTime));
	const [savingSettings, setSavingSettings] = (0, import_react.useState)(false);
	const backup = async () => {
		const data = await exportAdminData();
		const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `habshi-masjid-backup-${snapshot.today}.json`;
		link.click();
		URL.revokeObjectURL(url);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Application",
			title: "Settings & backup",
			description: "Community calendar uses Asia/Kolkata. Store data on a persistent server volume."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "surface-card space-y-3 p-4",
			onSubmit: async (event) => {
				event.preventDefault();
				const form = new FormData(event.currentTarget);
				setSavingSettings(true);
				try {
					const reminderTime = reminderTimeFromParts(reminderParts);
					await run(() => updateAppSettings({ data: {
						anchorDate: String(form.get("anchorDate") ?? ""),
						reminderTime
					} }), `Settings saved. Duty reminders are scheduled for ${formatReminderTime(reminderTime)} IST.`);
				} catch (error) {
					toast.error("Invalid reminder time", { description: error instanceof Error ? error.message : "Choose a valid time." });
				} finally {
					setSavingSettings(false);
				}
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Rotation start date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "anchorDate",
						type: "date",
						required: true,
						defaultValue: snapshot.settings.anchorDate
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-sm font-medium text-foreground",
					children: "Daily reminder time (IST)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs text-muted-foreground",
							children: ["Hour", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: reminderParts.hour,
								onChange: (event) => setReminderParts((current) => ({
									...current,
									hour: event.target.value
								})),
								className: "mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground",
								children: Array.from({ length: 12 }, (_, index) => String(index + 1)).map((hour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: hour,
									children: hour
								}, hour))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs text-muted-foreground",
							children: ["Minute", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: reminderParts.minute,
								onChange: (event) => setReminderParts((current) => ({
									...current,
									minute: event.target.value
								})),
								className: "mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground",
								children: Array.from({ length: 60 }, (_, minute) => String(minute).padStart(2, "0")).map((minute) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: minute,
									children: minute
								}, minute))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs text-muted-foreground",
							children: ["AM / PM", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: reminderParts.period,
								onChange: (event) => setReminderParts((current) => ({
									...current,
									period: event.target.value
								})),
								className: "mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "AM",
									children: "AM"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "PM",
									children: "PM"
								})]
							})]
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Saved time: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [formatReminderTime(snapshot.settings.reminderTime), " IST"] }),
						". The Node scheduler checks the saved setting every 15 seconds; a host cron can also call the secured scheduler endpoint."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: savingSettings,
					children: savingSettings ? "Saving…" : "Save settings"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Backup" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Each updated JSON file keeps up to 10 previous versions under the private data directory. Export a full admin-only backup for off-server recovery."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-3",
				variant: "outline",
				onClick: () => void run(backup, "Backup downloaded"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Download full backup"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Hosting requirements" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-4 text-sm text-muted-foreground",
			children: "Use a persistent Node.js host with a mounted writable volume. Cloudflare Workers and other ephemeral/serverless filesystems cannot store this JSON data safely."
		})
	] });
}
function formatTimestamp(value) {
	return new Intl.DateTimeFormat("en-IN", {
		timeZone: "Asia/Kolkata",
		day: "numeric",
		month: "short",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23"
	}).format(new Date(value));
}
function Metric({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card min-w-0 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-9 place-items-center rounded-xl bg-primary-soft text-primary",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs font-medium text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 truncate font-display text-xl font-semibold text-foreground",
				children: value
			})
		]
	});
}
function MiniMetric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card p-3 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl font-semibold text-foreground",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		})]
	});
}
function FeeMetric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card min-w-0 p-3 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "truncate font-display text-lg font-semibold text-foreground",
			children: formatINR(value)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		})]
	});
}
function ActionCard({ icon, title, detail, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		className: "surface-card flex items-start gap-3 p-4 text-left transition-transform active:scale-[0.99]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-10 shrink-0 place-items-center rounded-xl bg-gold-soft text-gold-foreground",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-semibold text-foreground",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-xs text-muted-foreground",
				children: detail
			})]
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5 text-sm font-medium text-foreground",
		children: [label, children]
	});
}
//#endregion
export { AdminDashboard as component };

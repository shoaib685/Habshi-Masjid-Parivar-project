import { i as formatDate } from "./date-0gm0zi69.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as Pill, r as PageHeader } from "./ui-B-mPjvYk.mjs";
import { C as CalendarHeart, E as BellRing, p as Info, s as Pin } from "../_libs/lucide-react.mjs";
import { t as Route } from "./announcements-BMwvfvgu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/announcements-BSGhfIVM.js
var import_jsx_runtime = require_jsx_runtime();
var ICON = {
	Event: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarHeart, { className: "size-4" }),
	Reminder: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellRing, { className: "size-4" }),
	Notice: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" })
};
function AnnouncementsPage() {
	const list = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "From the committee",
		title: "Announcements"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: list.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: a.pinned ? "surface-card animate-rise border-gold/60 p-5" : "surface-card animate-rise p-5",
			style: { animationDelay: `${i * 60}ms` },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-8 place-items-center rounded-full bg-gold-soft text-gold-foreground",
							children: ICON[a.tag]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							tone: a.tag === "Event" ? "gold" : a.tag === "Reminder" ? "primary" : "muted",
							children: a.tag
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-auto flex items-center gap-1.5 text-xs text-muted-foreground",
							children: [a.pinned && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-3.5" }), formatDate(a.date, {
								day: "numeric",
								month: "short",
								year: "numeric"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 text-xl font-semibold text-foreground",
					children: a.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-[15px] leading-relaxed text-muted-foreground",
					children: a.body
				})
			]
		}, a.id))
	})] });
}
//#endregion
export { AnnouncementsPage as component };

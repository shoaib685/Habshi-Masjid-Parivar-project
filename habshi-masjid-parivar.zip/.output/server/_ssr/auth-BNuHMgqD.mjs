import { createHmac, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { env } from "node:process";
import { promisify } from "node:util";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BNuHMgqD.js
var scrypt$1 = promisify(scrypt);
var SESSION_TTL_SECONDS = 720 * 60;
var ATTEMPT_WINDOW_MS = 900 * 1e3;
var ATTEMPT_LIMIT = 5;
var failedAttempts = /* @__PURE__ */ new Map();
function checkLoginRateLimit(key, now = Date.now()) {
	const current = failedAttempts.get(key);
	if (!current || now - current.since >= ATTEMPT_WINDOW_MS) {
		failedAttempts.set(key, {
			count: 0,
			since: now
		});
		return true;
	}
	return current.count < ATTEMPT_LIMIT;
}
function recordFailedLogin(key, now = Date.now()) {
	const current = failedAttempts.get(key);
	if (!current || now - current.since >= ATTEMPT_WINDOW_MS) {
		failedAttempts.set(key, {
			count: 1,
			since: now
		});
		return;
	}
	current.count += 1;
}
function clearFailedLogins(key) {
	failedAttempts.delete(key);
}
async function verifyAdminPassword(password) {
	const match = env["ADMIN_PASSWORD_HASH"]?.match(/^scrypt\$([a-f0-9]{32})\$([a-f0-9]{128})$/i);
	if (!match) throw new Error("ADMIN_PASSWORD_HASH is missing or invalid.");
	const [, salt, expectedHex] = match;
	if (!salt || !expectedHex) throw new Error("ADMIN_PASSWORD_HASH is invalid.");
	const actual = await scrypt$1(password, Buffer.from(salt, "hex"), 64);
	const expected = Buffer.from(expectedHex, "hex");
	return actual.length === expected.length && timingSafeEqual(actual, expected);
}
function createAdminSession() {
	const body = `${Math.floor(Date.now() / 1e3) + SESSION_TTL_SECONDS}.${randomBytes(16).toString("base64url")}`;
	return `${body}.${sign(body)}`;
}
function verifyAdminSession(token, now = Date.now()) {
	if (!token) return false;
	const [expires, nonce, signature, extra] = token.split(".");
	if (!expires || !nonce || !signature || extra) return false;
	const expiresAt = Number(expires);
	if (!Number.isSafeInteger(expiresAt) || expiresAt <= Math.floor(now / 1e3)) return false;
	const expected = sign(`${expires}.${nonce}`);
	const actualBuffer = Buffer.from(signature);
	const expectedBuffer = Buffer.from(expected);
	return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}
function sessionCookie(token, secure) {
	return [
		`hmp_admin=${token}`,
		"Path=/",
		"HttpOnly",
		"SameSite=Strict",
		`Max-Age=${SESSION_TTL_SECONDS}`,
		...secure ? ["Secure"] : []
	].join("; ");
}
function clearedSessionCookie(secure) {
	return [
		"hmp_admin=",
		"Path=/",
		"HttpOnly",
		"SameSite=Strict",
		"Max-Age=0",
		...secure ? ["Secure"] : []
	].join("; ");
}
function getSessionToken(cookieHeader) {
	return (cookieHeader?.split(";").map((part) => part.trim()).find((part) => part.startsWith("hmp_admin=")))?.slice(10);
}
function sign(value) {
	const secret = env["ADMIN_SESSION_SECRET"];
	if (!secret || Buffer.byteLength(secret) < 32) throw new Error("ADMIN_SESSION_SECRET must contain at least 32 bytes.");
	return createHmac("sha256", secret).update(value).digest("base64url");
}
//#endregion
export { checkLoginRateLimit, clearFailedLogins, clearedSessionCookie, createAdminSession, getSessionToken, recordFailedLogin, sessionCookie, verifyAdminPassword, verifyAdminSession };

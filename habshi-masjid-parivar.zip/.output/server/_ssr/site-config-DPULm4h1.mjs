//#region node_modules/.nitro/vite/services/ssr/assets/site-config-DPULm4h1.js
var MASJID = {
	name: "Habshi Masjid Parivar",
	shortName: "Masjid Parivar",
	city: "Jalore, Rajasthan",
	reminderTime: "08:00 AM IST"
};
//#endregion
export { MASJID as t };

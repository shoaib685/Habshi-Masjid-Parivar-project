import { a as numberType, c as unionType, i as literalType, n as booleanType, o as objectType, r as enumType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-schemas-gms4ftdc.js
var calendarDate = stringType().regex(/^\d{4}-\d{2}-\d{2}$/);
var monthKey = stringType().regex(/^\d{4}-\d{2}$/);
var phone = stringType().trim().regex(/^\+?[0-9 ()-]{7,20}$/);
var familySchema = objectType({
	id: stringType().regex(/^HMP-\d{3,}$/),
	name: stringType().trim().min(1).max(120),
	head: stringType().trim().max(120).default(""),
	contactNumber: phone,
	members: numberType().int().min(1).max(100).default(1),
	mohalla: stringType().trim().max(100).default(""),
	active: booleanType().default(true),
	order: numberType().int().min(1),
	monthlyFee: numberType().int().min(0).max(1e6),
	notificationCodeHash: stringType().regex(/^[a-f0-9]{64}$/i).optional()
});
var dutySchema = objectType({
	date: calendarDate,
	familyId: stringType().regex(/^HMP-\d{3,}$/).nullable(),
	status: enumType([
		"pending",
		"completed",
		"overridden",
		"skipped"
	]),
	note: stringType().trim().max(500).default("")
});
var foodSchema = objectType({
	id: stringType().uuid(),
	date: calendarDate,
	title: stringType().trim().min(1).max(120),
	description: stringType().trim().max(1e3).default(""),
	updatedAt: stringType().datetime()
});
var contributionSchema = objectType({
	id: stringType().uuid(),
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	month: monthKey,
	amount: numberType().int().positive().max(1e6),
	method: enumType(["cash", "upi"]),
	paidOn: calendarDate,
	note: stringType().trim().max(300).default("")
});
var familyPaymentSchema = objectType({
	id: stringType().uuid(),
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	month: monthKey,
	amountDue: numberType().int().min(0).max(1e6),
	amountReceived: numberType().int().min(0).max(1e6),
	history: arrayType(unionType([objectType({
		id: stringType().uuid(),
		at: stringType().datetime(),
		amountDue: numberType().int().min(0),
		amountReceived: numberType().int().min(0),
		note: stringType().max(300)
	}), objectType({
		id: stringType().uuid(),
		at: stringType().datetime(),
		amount: numberType().int().positive().max(1e6),
		method: enumType(["cash", "upi"]),
		note: stringType().max(300)
	})]))
}).superRefine((payment, context) => {
	if (payment.amountReceived > payment.amountDue) context.addIssue({
		code: "custom",
		message: "Received amount cannot exceed the amount due.",
		path: ["amountReceived"]
	});
	payment.history.forEach((entry, index) => {
		if ("amountReceived" in entry && entry.amountReceived > entry.amountDue) context.addIssue({
			code: "custom",
			message: "Received amount cannot exceed the amount due.",
			path: [
				"history",
				index,
				"amountReceived"
			]
		});
	});
});
var announcementSchema = objectType({
	id: stringType().uuid(),
	title: stringType().trim().min(1).max(160),
	body: stringType().trim().min(1).max(3e3),
	date: calendarDate,
	tag: enumType([
		"Notice",
		"Event",
		"Reminder"
	]),
	pinned: booleanType().default(false)
});
var notificationSchema = objectType({
	id: stringType().uuid(),
	dedupeKey: stringType().min(1).max(200),
	dutyDate: calendarDate,
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	channel: enumType(["push", "sms"]),
	status: enumType([
		"queued",
		"sent",
		"failed",
		"not-configured",
		"skipped"
	]),
	createdAt: stringType().datetime(),
	scheduledTime: stringType().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/).default("08:00"),
	deliveredAt: stringType().datetime().optional(),
	subscriptionId: stringType().uuid().optional(),
	detail: stringType().max(500).default("")
});
var pushSubscriptionSchema = objectType({
	id: stringType().uuid(),
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	endpoint: stringType().url().refine((value) => new URL(value).protocol === "https:"),
	keys: objectType({
		p256dh: stringType().min(20).max(256),
		auth: stringType().min(16).max(128)
	}),
	expirationTime: numberType().positive().nullable(),
	createdAt: stringType().datetime(),
	updatedAt: stringType().datetime()
});
var reminderTime = stringType().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/);
var settingsSchema = objectType({
	anchorDate: calendarDate,
	timezone: literalType("Asia/Kolkata"),
	reminderTime
});
var datasetSchemas = {
	families: arrayType(familySchema),
	duties: arrayType(dutySchema),
	food: arrayType(foodSchema),
	payments: arrayType(familyPaymentSchema),
	contributions: arrayType(contributionSchema),
	announcements: arrayType(announcementSchema),
	notifications: arrayType(notificationSchema),
	pushSubscriptions: arrayType(pushSubscriptionSchema),
	settings: settingsSchema
};
var emptyDatasets = {
	families: [],
	duties: [],
	food: [],
	payments: [],
	contributions: [],
	announcements: [],
	notifications: [],
	pushSubscriptions: [],
	settings: {
		anchorDate: "2026-01-01",
		timezone: "Asia/Kolkata",
		reminderTime: "08:00"
	}
};
var familyInputSchema = familySchema.omit({
	id: true,
	order: true,
	notificationCodeHash: true
}).extend({ active: booleanType().default(true) });
var contributionInputSchema = contributionSchema.omit({ id: true });
var paymentInputSchema = objectType({
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	month: monthKey,
	amountDue: numberType().int().min(0).max(1e6),
	amountPaid: numberType().int().min(0).max(1e6),
	method: enumType(["cash", "upi"]),
	note: stringType().trim().max(300).default("")
});
var dutyInputSchema = objectType({
	date: calendarDate,
	familyId: stringType().regex(/^HMP-\d{3,}$/).nullable(),
	status: enumType([
		"pending",
		"completed",
		"overridden",
		"skipped"
	]),
	note: stringType().trim().max(500).default("")
});
var pushSubscriptionInputSchema = objectType({
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	registrationCode: stringType().min(8).max(64),
	endpoint: pushSubscriptionSchema.shape.endpoint,
	keys: pushSubscriptionSchema.shape.keys,
	expirationTime: pushSubscriptionSchema.shape.expirationTime
});
//#endregion
export { emptyDatasets as a, paymentInputSchema as c, dutyInputSchema as i, pushSubscriptionInputSchema as l, contributionInputSchema as n, familyInputSchema as o, datasetSchemas as r, foodSchema as s, announcementSchema as t, settingsSchema as u };

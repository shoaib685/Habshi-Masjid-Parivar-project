import { l as getPublicDutyData } from "./admin-api-CHwB38Wv.mjs";
import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/duty-CIFumdY2.js
var $$splitComponentImporter = () => import("./duty-Dbt4UuCh.mjs");
var Route = createFileRoute("/duty")({
	loader: () => getPublicDutyData(),
	head: () => ({ meta: [
		{ title: "Today's Food Duty — Habshi Masjid Parivar" },
		{
			name: "description",
			content: "Which family is serving food at Habshi Masjid today, plus yesterday, tomorrow and recent duty history."
		},
		{
			property: "og:title",
			content: "Today's Food Duty — Habshi Masjid Parivar"
		},
		{
			property: "og:description",
			content: "Which family is serving food at the masjid today."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

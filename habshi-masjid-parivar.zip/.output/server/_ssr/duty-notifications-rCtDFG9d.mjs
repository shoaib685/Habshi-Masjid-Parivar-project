import { i as formatDate, l as todayIST } from "./date-0gm0zi69.mjs";
import { a as zonedClock, n as reminderIsDue } from "./reminder-time-JjPPV1YP.mjs";
import { t as getDutyForDate } from "./rotation-RQTt1xw8.mjs";
import { n as sendPush } from "./push-provider-Dwk2D3sx.mjs";
import { t as jsonStore } from "./store-Bz97We1e.mjs";
import { randomUUID, timingSafeEqual } from "node:crypto";
import { env } from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/duty-notifications-rCtDFG9d.js
async function sendSms(to, body) {
	const provider = env["SMS_PROVIDER"];
	if (!provider) return {
		status: "not-configured",
		detail: "SMS provider credentials are not configured."
	};
	if (provider !== "twilio") return {
		status: "not-configured",
		detail: `Unsupported SMS provider "${provider}".`
	};
	const accountSid = env["TWILIO_ACCOUNT_SID"];
	const authToken = env["TWILIO_AUTH_TOKEN"];
	const from = env["TWILIO_FROM_NUMBER"];
	if (!accountSid || !authToken || !from) return {
		status: "not-configured",
		detail: "Twilio credentials or sender number are missing."
	};
	const recipient = to.replace(/[ ()-]/g, "");
	const normalizedRecipient = /^\d{10}$/.test(recipient) ? `+91${recipient}` : /^0\d{10}$/.test(recipient) ? `+91${recipient.slice(1)}` : /^91\d{10}$/.test(recipient) ? `+${recipient}` : recipient;
	if (!/^\+[1-9]\d{7,14}$/.test(normalizedRecipient)) return {
		status: "failed",
		detail: "Family contact number must be a valid E.164 number."
	};
	const request = new URLSearchParams({
		To: normalizedRecipient,
		From: from,
		Body: body
	});
	try {
		const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(accountSid)}/Messages.json`, {
			method: "POST",
			headers: {
				Authorization: `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString("base64")}`,
				"Content-Type": "application/x-www-form-urlencoded"
			},
			body: request
		});
		if (!response.ok) return {
			status: "failed",
			detail: `Twilio returned HTTP ${response.status}: ${(await response.text()).slice(0, 350)}`
		};
		return {
			status: "sent",
			detail: "SMS accepted by Twilio."
		};
	} catch (error) {
		return {
			status: "failed",
			detail: (error instanceof Error ? error.message : "SMS network request failed.").slice(0, 500)
		};
	}
}
var activeDeliveries = /* @__PURE__ */ new Set();
async function runDueDutyReminders(now = /* @__PURE__ */ new Date()) {
	const settings = await jsonStore.read("settings");
	if (!reminderIsDue(now, settings.reminderTime)) return {
		status: "not-due",
		dutyDate: zonedClock(now).date
	};
	const date = zonedClock(now).date;
	return runDutyReminder(date, settings.reminderTime, now);
}
async function runDutyReminder(date, scheduledTime, now = /* @__PURE__ */ new Date()) {
	const [families, duties, subscriptions, settings] = await Promise.all([
		jsonStore.read("families"),
		jsonStore.read("duties"),
		jsonStore.read("pushSubscriptions"),
		jsonStore.read("settings")
	]);
	const family = assignedFamily(date, families, duties, settings.anchorDate);
	if (!family) return {
		status: "no-duty",
		dutyDate: date
	};
	const deliveryKey = `duty:${date}:${family.id}`;
	if (activeDeliveries.has(deliveryKey)) return {
		status: "already-running",
		dutyDate: date,
		familyId: family.id
	};
	activeDeliveries.add(deliveryKey);
	try {
		const familySubscriptions = subscriptions.filter((item) => item.familyId === family.id);
		const title = "Today's food duty";
		const body = `${family.name}: your family is assigned food duty for ${formatDate(date, {
			weekday: "long",
			day: "numeric",
			month: "long"
		})}.`;
		let pushSucceeded = false;
		let pushFailed = false;
		let pushAlreadyAttempted = false;
		if (!familySubscriptions.length) {
			await deliverOnce({
				date,
				family,
				channel: "push",
				scheduledTime,
				now,
				dedupeKey: `duty:${date}:${family.id}:push:none`,
				detail: "No active push subscriptions are registered for this family.",
				deliver: async () => ({
					status: "not-configured",
					detail: "No push subscription registered."
				})
			});
			pushFailed = true;
		} else for (const subscription of familySubscriptions) {
			const result = await deliverOnce({
				date,
				family,
				channel: "push",
				scheduledTime,
				subscriptionId: subscription.id,
				now,
				dedupeKey: `duty:${date}:${family.id}:push:${subscription.id}`,
				detail: "Push notification was queued.",
				deliver: async () => {
					if (subscription.expirationTime && subscription.expirationTime <= now.getTime()) {
						await removeExpiredSubscription(subscription.id);
						return {
							status: "failed",
							detail: "Push subscription has expired.",
							expired: true
						};
					}
					const result = await sendPush(subscription, {
						title,
						body,
						url: "/duty"
					});
					if (result.status === "failed" && result.expired) await removeExpiredSubscription(subscription.id);
					return result;
				}
			});
			if (result === "sent") pushSucceeded = true;
			else if (result === "failed" || result === "not-configured") pushFailed = true;
			else if (result === "already-attempted") {
				const existing = (await jsonStore.read("notifications")).find((item) => item.dedupeKey === `duty:${date}:${family.id}:push:${subscription.id}`);
				if (existing?.status === "sent") pushSucceeded = true;
				if (existing?.status === "failed" || existing?.status === "not-configured") pushFailed = true;
				if (existing?.status === "queued" || !existing) pushAlreadyAttempted = true;
			}
		}
		if (!pushAlreadyAttempted && (!pushSucceeded || pushFailed)) {
			const result = await deliverOnce({
				date,
				family,
				channel: "sms",
				scheduledTime,
				now,
				dedupeKey: `duty:${date}:${family.id}:sms`,
				detail: "SMS fallback was queued after push was unavailable or failed.",
				deliver: () => family.contactNumber ? sendSms(family.contactNumber, body) : Promise.resolve({
					status: "not-configured",
					detail: "Family phone is missing."
				})
			});
			return {
				status: pushSucceeded || result === "sent" ? "sent" : result === "failed" ? "failed" : result === "not-configured" ? "not-configured" : "already-attempted",
				dutyDate: date,
				familyId: family.id,
				sms: result
			};
		}
		if (!pushSucceeded && pushAlreadyAttempted) return {
			status: "already-attempted",
			dutyDate: date,
			familyId: family.id
		};
		await deliverOnce({
			date,
			family,
			channel: "sms",
			scheduledTime,
			now,
			dedupeKey: `duty:${date}:${family.id}:sms`,
			detail: "Skipped because push delivery succeeded.",
			deliver: async () => ({
				status: "skipped",
				detail: "Push delivery succeeded."
			})
		});
		return {
			status: "sent",
			dutyDate: date,
			familyId: family.id,
			sms: "skipped"
		};
	} finally {
		activeDeliveries.delete(deliveryKey);
	}
}
function assignedFamily(date, families, records, anchorDate = "1970-01-01") {
	const config = {
		families: families.map((family) => ({ ...family })),
		anchorDate,
		overrides: records.flatMap((duty) => {
			if (duty.status === "skipped") return [{
				date: duty.date,
				kind: "skip",
				note: duty.note
			}];
			if (duty.status === "overridden" && duty.familyId) return [{
				date: duty.date,
				kind: "reassign",
				familyId: duty.familyId,
				note: duty.note
			}];
			return [];
		})
	};
	const saved = records.find((item) => item.date === date);
	if (saved?.status === "skipped") return null;
	if ((saved?.status === "completed" || saved?.status === "overridden") && saved.familyId) return families.find((item) => item.id === saved.familyId) ?? null;
	const assigned = getDutyForDate(date, config, todayIST()).family;
	return assigned ? families.find((item) => item.id === assigned.id) ?? null : null;
}
async function deliverOnce({ date, family, channel, scheduledTime, subscriptionId, now, dedupeKey, detail, deliver }) {
	const createdAt = now.toISOString();
	const log = {
		id: randomUUID(),
		dedupeKey,
		dutyDate: date,
		familyId: family.id,
		channel,
		status: "queued",
		createdAt,
		scheduledTime,
		...subscriptionId ? { subscriptionId } : {},
		detail
	};
	let reserved = false;
	await jsonStore.update("notifications", (logs) => {
		if (logs.some((item) => item.dedupeKey === dedupeKey)) return logs;
		reserved = true;
		return [...logs, log];
	});
	if (!reserved) {
		const existing = (await jsonStore.read("notifications")).find((item) => item.dedupeKey === dedupeKey);
		return existing?.status === "queued" ? "already-attempted" : existing?.status ?? "already-attempted";
	}
	let result;
	try {
		result = await deliver();
	} catch (error) {
		result = {
			status: "failed",
			detail: (error instanceof Error ? error.message : "Notification delivery failed.").slice(0, 500)
		};
	}
	const deliveredAt = result.status === "sent" ? (/* @__PURE__ */ new Date()).toISOString() : void 0;
	await jsonStore.update("notifications", (logs) => logs.map((item) => item.dedupeKey === dedupeKey ? {
		...item,
		status: result.status,
		detail: result.detail.slice(0, 500),
		...deliveredAt ? { deliveredAt } : {}
	} : item));
	return result.status;
}
async function removeExpiredSubscription(id) {
	await jsonStore.update("pushSubscriptions", (subscriptions) => subscriptions.filter((item) => item.id !== id));
}
function isSchedulerSecretValid(authorization) {
	const expected = env["HMP_SCHEDULER_SECRET"];
	if (!expected || Buffer.byteLength(expected) < 32 || !authorization?.startsWith("Bearer ")) return false;
	const supplied = Buffer.from(authorization.slice(7));
	const actual = Buffer.from(expected);
	return supplied.length === actual.length && timingSafeEqual(supplied, actual);
}
//#endregion
export { isSchedulerSecretValid, runDueDutyReminders };

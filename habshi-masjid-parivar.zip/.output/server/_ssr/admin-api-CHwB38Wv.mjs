import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-klzoUz4R.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-Bvl9IsNH.mjs";
import { a as numberType, o as objectType, s as stringType } from "../_libs/zod.mjs";
import { c as paymentInputSchema, i as dutyInputSchema, l as pushSubscriptionInputSchema, n as contributionInputSchema, o as familyInputSchema, s as foodSchema, t as announcementSchema, u as settingsSchema } from "./data-schemas-gms4ftdc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-api-CHwB38Wv.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var credentialsSchema = objectType({ password: stringType().min(1).max(200) });
var idSchema = objectType({ id: stringType().uuid() });
var foodInputSchema = foodSchema.omit({
	id: true,
	updatedAt: true
});
var announcementInputSchema = announcementSchema.omit({ id: true });
var settingsInputSchema = settingsSchema.omit({ timezone: true });
var pushRemovalSchema = objectType({
	familyId: stringType().regex(/^HMP-\d{3,}$/),
	registrationCode: stringType().min(8).max(64),
	endpoint: stringType().url()
});
var loginAdmin = createServerFn({ method: "POST" }).validator(credentialsSchema).handler(createSsrRpc("1eab9d132768bdafdc65b33e25e4f903cd4c52de98aec914f8da35dace92a072"));
var checkAdminSession = createServerFn({ method: "GET" }).handler(createSsrRpc("f9014ac7d2c5cd4774ab45450be55d60658d7e56f0421bcd22f8366d2c105216"));
var logoutAdmin = createServerFn({ method: "POST" }).handler(createSsrRpc("79224b5fd95c789c7e5fdcf6abfe09d41d75e59fddb39af91891439bb93379d7"));
var getPublicHomeData = createServerFn({ method: "GET" }).handler(createSsrRpc("5f3a908e03039500f8a20d5524c4c991c2eeba9728bfd1e8eea16c5407092e05"));
var getPublicPushConfig = createServerFn({ method: "GET" }).handler(createSsrRpc("d0739ef64ca32153770dd8f14f02643989f575ead95280feba6c10866b953036"));
var subscribeFamilyPush = createServerFn({ method: "POST" }).validator(pushSubscriptionInputSchema).handler(createSsrRpc("0a85feaa4f0c0f889baa14879e7f05c60544e30d6d6013a837d1177f5a9cb789"));
var removeFamilyPushSubscription = createServerFn({ method: "POST" }).validator(pushRemovalSchema).handler(createSsrRpc("8ee5bf2d60bbe64d8347437de200cf3fc443ea3636172ddb932465769ffd28d2"));
var issueFamilyPushCode = createServerFn({ method: "POST" }).validator(objectType({ familyId: stringType().regex(/^HMP-\d{3,}$/) })).handler(createSsrRpc("05c4a016655e0329b56236b197fd1494c1369126db161d83195ca29745585b53"));
var getPublicSchedule = createServerFn({ method: "GET" }).handler(createSsrRpc("7530b3188d63024a7dc29ce58dc7e075ff20d57e9b89bac0ebc459e31424256d"));
var getPublicDutyData = createServerFn({ method: "GET" }).handler(createSsrRpc("aa132b913dc885918e0a3a51d7dd4fa6f7cf9770073af8dc7b8672762c0ba3d5"));
var getPublicAnnouncements = createServerFn({ method: "GET" }).handler(createSsrRpc("850115e2cd0fad0d30b83b89237afd1e39d461b2cfc13d447f682b11b620dab6"));
var getPublicContributions = createServerFn({ method: "GET" }).handler(createSsrRpc("653e1729ba5eb3418da627af40a05761a45ae5a649d16e6b0addb273eb37a69d"));
var getAdminSnapshot = createServerFn({ method: "GET" }).handler(createSsrRpc("6a8ee610d51f73fefdabb81054f4d4f3b87a4f459e7f9779128ce54ad5b459f7"));
var createFamily = createServerFn({ method: "POST" }).validator(familyInputSchema).handler(createSsrRpc("29af26f21b77e455b7f0a5fb0a6ba5313610cac834ad3f7c81d88dd6debef88e"));
var updateFamily = createServerFn({ method: "POST" }).validator(familyInputSchema.extend({
	id: stringType().regex(/^HMP-\d{3,}$/),
	order: numberType().int().min(1)
})).handler(createSsrRpc("1e675813f744cc8dd80722dc46c702891955c246516207c98c0365a51828fe4d"));
var setDuty = createServerFn({ method: "POST" }).validator(dutyInputSchema).handler(createSsrRpc("8b5712bdb7e546818e3cc2fbe6c2eeb8e02821fca4281c0f1456167c38043c3b"));
var createFoodEntry = createServerFn({ method: "POST" }).validator(foodInputSchema).handler(createSsrRpc("5f74ff7d2af2d08eb1955e3a6cf57552f02ea306585cbb29e82a7ce7a13edc6f"));
var removeFoodEntry = createServerFn({ method: "POST" }).validator(idSchema).handler(createSsrRpc("7eb70b42329ee0a51d1c5c5efab0d2f101cb3c4fbf315decb9f34a8780fcf3c4"));
var updateFoodEntry = createServerFn({ method: "POST" }).validator(foodInputSchema.extend({ id: stringType().uuid() })).handler(createSsrRpc("e684a66cdc976cf7dd1af0523f720500a2d35bb6175f57f2cad6a9a80f9d67ae"));
var saveFamilyPayment = createServerFn({ method: "POST" }).validator(paymentInputSchema).handler(createSsrRpc("3798b847917dbc38e09d62e6b186c9cffd00edf5319d9f3d0c81686b56cef006"));
var recordContribution = createServerFn({ method: "POST" }).validator(contributionInputSchema).handler(createSsrRpc("6170a0edf0250863be9d8b49271e353d5b611b71e57e813dd1637cd0cde721ef"));
var createAnnouncement = createServerFn({ method: "POST" }).validator(announcementInputSchema).handler(createSsrRpc("4232dfb53cba7370a9b72a77d256435bda64b1a316b0d3b90561161f12ed2e80"));
var removeAnnouncement = createServerFn({ method: "POST" }).validator(idSchema).handler(createSsrRpc("36fdbe0f2f1b12dfea097a8fc7e50362c5f76a61e027c68c9f5241a6793dbb20"));
var updateAnnouncement = createServerFn({ method: "POST" }).validator(announcementInputSchema.extend({ id: stringType().uuid() })).handler(createSsrRpc("087e18b0b1b03f6adaf70954aa4cdbb5664291b81b9ee72ca44036d06eba1f19"));
var exportAdminData = createServerFn({ method: "GET" }).handler(createSsrRpc("1300736cc7aba35c5570b76c752dd0c7b20e92ce7ba93216ee8373130c841862"));
var updateAppSettings = createServerFn({ method: "POST" }).validator(settingsInputSchema).handler(createSsrRpc("6a3155a33aaff31ec66babd76ab9de47b3f8c0a01473446d8945c7414e898637"));
//#endregion
export { updateAnnouncement as C, updateFoodEntry as E, subscribeFamilyPush as S, updateFamily as T, removeAnnouncement as _, exportAdminData as a, saveFamilyPayment as b, getPublicContributions as c, getPublicPushConfig as d, getPublicSchedule as f, recordContribution as g, logoutAdmin as h, createFoodEntry as i, getPublicDutyData as l, loginAdmin as m, createAnnouncement as n, getAdminSnapshot as o, issueFamilyPushCode as p, createFamily as r, getPublicAnnouncements as s, checkAdminSession as t, getPublicHomeData as u, removeFamilyPushSubscription as v, updateAppSettings as w, setDuty as x, removeFoodEntry as y };

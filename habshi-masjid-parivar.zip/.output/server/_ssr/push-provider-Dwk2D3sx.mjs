import { n as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as setVapidDetails, t as sendNotification } from "../_libs/web-push.mjs";
import { env } from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/push-provider-Dwk2D3sx.js
var push_provider_Dwk2D3sx_exports = /* @__PURE__ */ __exportAll({
	n: () => sendPush,
	t: () => push_provider_exports
});
var push_provider_exports = /* @__PURE__ */ __exportAll$1({
	getPushPublicKey: () => getPushPublicKey,
	sendPush: () => sendPush
});
function getPushPublicKey() {
	const key = env["VAPID_PUBLIC_KEY"];
	return key && env["VAPID_PRIVATE_KEY"] && env["VAPID_SUBJECT"] ? key : null;
}
async function sendPush(subscription, payload) {
	const publicKey = env["VAPID_PUBLIC_KEY"];
	const privateKey = env["VAPID_PRIVATE_KEY"];
	const subject = env["VAPID_SUBJECT"];
	if (!publicKey || !privateKey || !subject) return {
		status: "not-configured",
		detail: "VAPID keys or subject are not configured."
	};
	try {
		setVapidDetails(subject, publicKey, privateKey);
		await sendNotification(subscription, JSON.stringify(payload), { TTL: 3600 });
		return {
			status: "sent",
			detail: "Push delivered to device."
		};
	} catch (error) {
		const statusCode = typeof error === "object" && error !== null && "statusCode" in error ? Number(error.statusCode) : 0;
		const expired = statusCode === 404 || statusCode === 410;
		const detail = error instanceof Error ? error.message.replace(/https?:\/\/\S+/g, "[push endpoint]") : "Push failed.";
		return {
			status: "failed",
			detail: `Push provider ${statusCode ? `(${statusCode}) ` : ""}${detail}`.slice(0, 500),
			expired
		};
	}
}
//#endregion
export { sendPush as n, push_provider_Dwk2D3sx_exports as t };

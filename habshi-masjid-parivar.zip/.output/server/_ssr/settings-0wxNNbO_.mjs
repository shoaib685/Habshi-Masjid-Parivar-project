import { i as __toESM } from "../_runtime.mjs";
import { S as subscribeFamilyPush, d as getPublicPushConfig, v as removeFamilyPushSubscription } from "./admin-api-CHwB38Wv.mjs";
import { c as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SectionTitle, r as PageHeader } from "./ui-B-mPjvYk.mjs";
import { t as MASJID } from "./site-config-DPULm4h1.mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as Bell, _ as Download, a as Share, i as ShieldCheck, l as MapPin, p as Info, r as Smartphone, x as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-DX_6BsEM.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-0wxNNbO_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Tracks whether the app can be installed to the home screen on this device. */
function useInstallPrompt() {
	const [state, setState] = (0, import_react.useState)("unknown");
	const [deferred, setDeferred] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true) {
			setState("installed");
			return;
		}
		const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
		setState(isIOS ? "ios" : "manual");
		const onPrompt = (e) => {
			e.preventDefault();
			setDeferred(e);
			setState("available");
		};
		const onInstalled = () => setState("installed");
		window.addEventListener("beforeinstallprompt", onPrompt);
		window.addEventListener("appinstalled", onInstalled);
		return () => {
			window.removeEventListener("beforeinstallprompt", onPrompt);
			window.removeEventListener("appinstalled", onInstalled);
		};
	}, []);
	const install = async () => {
		if (!deferred) return;
		await deferred.prompt();
		if ((await deferred.userChoice).outcome === "accepted") setState("installed");
		setDeferred(null);
	};
	return {
		state,
		install
	};
}
function useNotificationPermission() {
	const [state, setState] = (0, import_react.useState)("unknown");
	(0, import_react.useEffect)(() => {
		if (!("Notification" in window)) setState("unsupported");
		else if (window.top !== window.self && Notification.permission === "default") setState("in-frame");
		else setState(Notification.permission);
	}, []);
	const request = async () => {
		if (!("Notification" in window)) return null;
		if (window.top !== window.self) {
			setState("in-frame");
			return null;
		}
		const result = await Notification.requestPermission();
		setState(result);
		return result;
	};
	return {
		state,
		request
	};
}
function SettingsPage() {
	const install = useInstallPrompt();
	const notify = useNotificationPermission();
	const [pushPublicKey, setPushPublicKey] = (0, import_react.useState)(null);
	const [familyId, setFamilyId] = (0, import_react.useState)("");
	const [registrationCode, setRegistrationCode] = (0, import_react.useState)("");
	const [pushSubscription, setPushSubscription] = (0, import_react.useState)(null);
	const [pushBusy, setPushBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let active = true;
		getPublicPushConfig().then(({ publicKey }) => {
			if (active) setPushPublicKey(publicKey);
		}).catch((error) => console.error("Could not load push configuration.", error));
		if ("serviceWorker" in navigator && "PushManager" in window) navigator.serviceWorker.ready.then((registration) => registration.pushManager.getSubscription()).then((subscription) => {
			if (active) setPushSubscription(subscription);
		}).catch((error) => console.error("Could not inspect this device's push setup.", error));
		return () => {
			active = false;
		};
	}, []);
	const enablePush = async () => {
		if (!pushPublicKey) {
			toast.error("Push notifications are not configured on this server.");
			return;
		}
		if (!familyId.trim() || !registrationCode.trim()) {
			toast.error("Enter your Family ID and notification setup code.");
			return;
		}
		setPushBusy(true);
		try {
			let permission = notify.state;
			if (permission !== "granted") permission = await notify.request() ?? "default";
			if (permission !== "granted") {
				toast.error(permission === "denied" ? "Allow notifications in your browser's site settings." : "Notification permission was not granted.");
				return;
			}
			const registration = await navigator.serviceWorker.ready;
			const subscription = await registration.pushManager.getSubscription() ?? await registration.pushManager.subscribe({
				userVisibleOnly: true,
				applicationServerKey: decodeVapidKey(pushPublicKey)
			});
			const values = subscription.toJSON();
			if (!values.endpoint || !values.keys?.["p256dh"] || !values.keys["auth"]) throw new Error("The browser returned an incomplete push subscription.");
			await subscribeFamilyPush({ data: {
				familyId: familyId.trim().toUpperCase(),
				registrationCode: registrationCode.trim(),
				endpoint: values.endpoint,
				keys: {
					p256dh: values.keys["p256dh"],
					auth: values.keys["auth"]
				},
				expirationTime: subscription.expirationTime
			} });
			setPushSubscription(subscription);
			setRegistrationCode("");
			toast.success("This device is registered for its family's duty reminders.");
		} catch (error) {
			toast.error("Could not enable push notifications", { description: error instanceof Error ? error.message : "Please try again." });
		} finally {
			setPushBusy(false);
		}
	};
	const disablePush = async () => {
		if (!pushSubscription) return;
		if (!familyId.trim() || !registrationCode.trim()) {
			toast.error("Enter your Family ID and notification setup code to disable this device.");
			return;
		}
		setPushBusy(true);
		try {
			await removeFamilyPushSubscription({ data: {
				familyId: familyId.trim().toUpperCase(),
				registrationCode: registrationCode.trim(),
				endpoint: pushSubscription.endpoint
			} });
			await pushSubscription.unsubscribe();
			setPushSubscription(null);
			setRegistrationCode("");
			toast.success("Push notifications disabled on this device.");
		} catch (error) {
			toast.error("Could not disable push notifications", { description: error instanceof Error ? error.message : "Please try again." });
		} finally {
			setPushBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "App",
			title: "Settings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Install the app" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/icons/icon-192.png",
					alt: "",
					width: 56,
					height: 56,
					className: "size-14 rounded-2xl"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-semibold text-foreground",
						children: MASJID.shortName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Add to your home screen and open it like any other app."
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					install.state === "installed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-success-soft px-4 py-3 text-sm font-semibold text-success",
						children: "Installed on this device"
					}),
					install.state === "available" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "hero",
						size: "lg",
						className: "w-full",
						onClick: install.install,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Install app"]
					}),
					install.state === "ios" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "space-y-2 rounded-xl bg-muted p-4 text-sm text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: "1."
								}),
								" Tap",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share, { className: "inline size-4 text-primary" }),
								" Share in Safari"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "2."
							}),
							" Choose",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "Add to Home Screen"
							})
						] })]
					}),
					(install.state === "manual" || install.state === "unknown") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted p-4 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "mr-1.5 inline size-4 text-primary" }),
							"Open this app in Chrome on your phone, then tap the menu (⋮) and choose",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-foreground",
								children: "Install app"
							}),
							" or",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-foreground",
								children: "Add to Home screen"
							}),
							"."
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Notifications" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 place-items-center rounded-xl bg-primary-soft text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold text-foreground",
							children: "Family-specific duty reminders"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								notify.state === "granted" && "Notifications are allowed on this device.",
								notify.state === "denied" && "Blocked — allow them in your browser's site settings",
								notify.state === "unsupported" && "Not supported in this browser",
								notify.state === "in-frame" && "Open the app in its own tab to allow notifications",
								(notify.state === "default" || notify.state === "unknown") && "Subscribe this device to receive reminders for one family, even when the app is closed."
							]
						})]
					})]
				}),
				!pushPublicKey && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-xl bg-muted p-3 text-sm text-muted-foreground",
					children: "Push delivery is not configured on this server yet."
				}),
				pushPublicKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [
						pushSubscription && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-success",
								children: "This device has an existing push subscription."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								disabled: pushBusy || !familyId.trim() || !registrationCode.trim(),
								onClick: disablePush,
								children: pushBusy ? "Updating…" : "Disable on this device"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: pushSubscription ? "Enter the family credentials to link or update this device." : "Ask the administrator for your permanent Family ID and a notification setup code."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium text-foreground",
							children: ["Family ID", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: familyId,
								onChange: (event) => setFamilyId(event.target.value),
								placeholder: "HMP-001",
								autoCapitalize: "characters",
								autoComplete: "off",
								className: "mt-1 h-11 w-full rounded-lg border border-input bg-background px-3"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium text-foreground",
							children: ["Notification setup code", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								value: registrationCode,
								onChange: (event) => setRegistrationCode(event.target.value),
								autoComplete: "one-time-code",
								className: "mt-1 h-11 w-full rounded-lg border border-input bg-background px-3"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "hero",
							className: "w-full",
							disabled: pushBusy || notify.state === "unsupported" || notify.state === "in-frame",
							onClick: enablePush,
							children: pushBusy ? "Enabling…" : pushSubscription ? "Update family registration" : "Enable family notifications"
						})
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "About" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card divide-y divide-border text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" }),
					label: "Community",
					value: MASJID.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
					label: "Location",
					value: MASJID.city
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }),
					label: "Time zone",
					value: "India (IST)"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Administration" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/admin/login",
			className: "surface-card flex items-center gap-3 p-5 transition-transform active:scale-[0.99]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-foreground",
						children: "Admin login"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "For the masjid administrator only"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-muted-foreground" })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 text-center text-xs text-muted-foreground",
			children: "Version 1.0 · Made for the Habshi Masjid community"
		})
	] });
}
function decodeVapidKey(value) {
	const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
	const raw = window.atob(base64);
	const bytes = new Uint8Array(new ArrayBuffer(raw.length));
	for (let index = 0; index < raw.length; index += 1) bytes[index] = raw.charCodeAt(index);
	return bytes;
}
function Row({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-5 py-3.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold text-foreground",
				children: value
			})
		]
	});
}
//#endregion
export { SettingsPage as component };

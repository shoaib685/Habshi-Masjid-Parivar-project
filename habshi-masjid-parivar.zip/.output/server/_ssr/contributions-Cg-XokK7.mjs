//#region node_modules/.nitro/vite/services/ssr/assets/contributions-Cg-XokK7.js
function contributionStatus(fee, collected) {
	if (collected >= fee) return "paid";
	if (collected > 0) return "partial";
	return "pending";
}
/** Voluntary contributions are independent of mandatory family payment balances. */
function summarizeContributions(month, contributions) {
	return contributions.filter((entry) => entry.month === month).reduce((summary, entry) => {
		summary.collected += entry.amount;
		summary.entries += 1;
		summary[entry.method] += entry.amount;
		return summary;
	}, {
		month,
		collected: 0,
		entries: 0,
		cash: 0,
		upi: 0
	});
}
function formatINR(amount) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(amount);
}
//#endregion
export { formatINR as n, summarizeContributions as r, contributionStatus as t };

import { n as addDays, r as daysBetween } from "./date-0gm0zi69.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rotation-RQTt1xw8.js
function activeRotation(families) {
	return families.filter((f) => f.active).sort((a, b) => a.order - b.order);
}
function getDutyForDate(date, config, today) {
	const queue = activeRotation(config.families);
	const override = config.overrides.find((o) => o.date === date);
	const offset = daysBetween(config.anchorDate, date);
	if (queue.length === 0 || offset < 0) return {
		date,
		family: null,
		scheduledFamily: null,
		status: "pending",
		override
	};
	const scheduledFamily = queue[(offset - config.overrides.filter((o) => o.kind === "skip" && o.date >= config.anchorDate && o.date < date).length) % queue.length] ?? null;
	if (override?.kind === "skip") return {
		date,
		family: null,
		scheduledFamily,
		status: "skipped",
		override
	};
	if (override && override.familyId) return {
		date,
		family: config.families.find((f) => f.id === override.familyId) ?? null,
		scheduledFamily,
		status: "overridden",
		override
	};
	return {
		date,
		family: scheduledFamily,
		scheduledFamily,
		status: date < today ? "completed" : "pending"
	};
}
function getSchedule(from, days, config, today) {
	return Array.from({ length: days }, (_, i) => getDutyForDate(addDays(from, i), config, today));
}
//#endregion
export { getSchedule as n, getDutyForDate as t };

import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-B-mPjvYk.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ eyebrow, title, description, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise mb-6 flex items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-[0.16em] text-primary",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-[1.9rem] font-semibold leading-tight text-foreground lg:text-4xl",
				children: title
			}),
			description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-sm text-muted-foreground",
				children: description
			})
		] }), action]
	});
}
function SectionTitle({ children, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 mt-8 flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold text-foreground",
			children
		}), action]
	});
}
function initials(name) {
	return name.replace(/^(Haji|Mohammed|Abdul)\s+/i, "").split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
}
var avatarVariants = cva("grid shrink-0 place-items-center rounded-2xl font-display font-semibold", {
	variants: {
		tone: {
			primary: "bg-primary-soft text-primary",
			gold: "gold-chip",
			muted: "bg-muted text-muted-foreground",
			onHero: "bg-primary-foreground/15 text-primary-foreground ring-1 ring-primary-foreground/25"
		},
		size: {
			sm: "size-10 text-sm",
			md: "size-12 text-base",
			lg: "size-16 text-xl"
		}
	},
	defaultVariants: {
		tone: "primary",
		size: "md"
	}
});
function FamilyAvatar({ name, className, ...variants }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(avatarVariants(variants), className),
		children: initials(name)
	});
}
var badgeVariants = cva("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wide", {
	variants: { tone: {
		success: "bg-success-soft text-success",
		warning: "bg-warning-soft text-warning",
		pending: "bg-pending-soft text-pending",
		primary: "bg-primary-soft text-primary",
		muted: "bg-muted text-muted-foreground",
		gold: "gold-chip"
	} },
	defaultVariants: { tone: "muted" }
});
function Pill({ children, className, ...variants }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants(variants), className),
		children
	});
}
var DUTY_LABEL = {
	completed: {
		label: "Completed",
		tone: "success"
	},
	pending: {
		label: "Pending",
		tone: "primary"
	},
	overridden: {
		label: "Changed",
		tone: "gold"
	},
	skipped: {
		label: "No duty",
		tone: "muted"
	}
};
function DutyStatusPill({ status }) {
	const s = DUTY_LABEL[status];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
		tone: s.tone,
		children: s.label
	});
}
//#endregion
export { SectionTitle as a, Pill as i, FamilyAvatar as n, PageHeader as r, DutyStatusPill as t };

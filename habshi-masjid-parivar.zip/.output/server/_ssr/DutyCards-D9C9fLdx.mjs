import { i as formatDate, s as relativeDayLabel } from "./date-0gm0zi69.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as FamilyAvatar, t as DutyStatusPill } from "./ui-B-mPjvYk.mjs";
import { t as MASJID } from "./site-config-DPULm4h1.mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as BellRing, l as MapPin, x as ChevronRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/DutyCards-D9C9fLdx.js
var import_jsx_runtime = require_jsx_runtime();
function TodayDutyHero({ duty, showDate = true, showReminder = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "surface-hero animate-rise p-6 lg:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.18em] text-gold",
					children: "Today's food duty"
				}), showDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-primary-foreground/75",
					children: formatDate(duty.date, {
						weekday: "short",
						day: "numeric",
						month: "short"
					})
				})]
			}),
			duty.family ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyAvatar, {
					name: duty.family.head,
					tone: "onHero",
					size: "lg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "line-clamp-2 text-[1.45rem] font-semibold leading-tight lg:text-3xl",
						children: duty.family.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm text-primary-foreground/80",
						children: duty.family.head
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-wrap gap-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 rounded-full bg-primary-foreground/12 px-3 py-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
						" ",
						duty.family.mohalla
					]
				}), duty.status === "overridden" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "gold-chip inline-flex items-center rounded-full px-3 py-1.5 font-semibold",
					children: "Changed by admin"
				})]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[1.6rem] font-semibold leading-tight",
					children: "No family duty today"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-primary-foreground/80",
					children: duty.override?.note ?? "The rotation continues tomorrow."
				})]
			}),
			showReminder && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center gap-2 border-t border-primary-foreground/15 pt-4 text-xs text-primary-foreground/75",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellRing, { className: "size-3.5 text-gold" }),
					"Reminder goes out every day at ",
					MASJID.reminderTime
				]
			})
		]
	});
}
function DutyRow({ duty, today }) {
	const isToday = duty.date === today;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3 px-4 py-3.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-12 shrink-0 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
					children: formatDate(duty.date, { weekday: "short" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: isToday ? "font-display text-xl font-semibold text-primary" : "font-display text-xl font-semibold text-foreground",
					children: formatDate(duty.date, { day: "numeric" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-9 w-px bg-border" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-semibold text-foreground",
					children: duty.family ? duty.family.name : "No family duty"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted-foreground",
					children: duty.family ? duty.status === "overridden" ? `In place of ${duty.scheduledFamily?.name ?? "—"}` : `${relativeDayLabel(duty.date, today)} · ${duty.family.mohalla}` : duty.override?.note ?? relativeDayLabel(duty.date, today)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyStatusPill, { status: duty.status })
		]
	});
}
function DutyList({ days, today }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "surface-card divide-y divide-border overflow-hidden",
		children: days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyRow, {
			duty: d,
			today
		}, d.date))
	});
}
function SeeAllLink({ to, label = "See all" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "inline-flex items-center gap-0.5 text-sm font-semibold text-primary",
		children: [
			label,
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
		]
	});
}
//#endregion
export { SeeAllLink as n, TodayDutyHero as r, DutyList as t };

import { u as getPublicHomeData } from "./admin-api-CHwB38Wv.mjs";
import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BgNElvcv.js
var $$splitComponentImporter = () => import("./routes-B6YH8162.mjs");
var Route = createFileRoute("/")({
	loader: () => getPublicHomeData(),
	head: () => ({ meta: [
		{ title: "Habshi Masjid Parivar — Today's food duty & community updates" },
		{
			name: "description",
			content: "See which family has food duty today, the upcoming rotation, monthly contribution totals and masjid announcements."
		},
		{
			property: "og:title",
			content: "Habshi Masjid Parivar"
		},
		{
			property: "og:description",
			content: "Today's food duty, upcoming schedule and community updates for Habshi Masjid, Jalore."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

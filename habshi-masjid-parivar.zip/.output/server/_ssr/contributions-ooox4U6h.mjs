import { i as __toESM } from "../_runtime.mjs";
import { n as formatINR } from "./contributions-Cg-XokK7.mjs";
import { a as formatMonth } from "./date-0gm0zi69.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SectionTitle, r as PageHeader } from "./ui-B-mPjvYk.mjs";
import { D as Banknote, d as Lock, r as Smartphone } from "../_libs/lucide-react.mjs";
import { t as Route } from "./contributions-C-Xj3fSq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contributions-ooox4U6h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContributionsPage() {
	const summaries = Route.useLoaderData();
	const current = summaries.at(-1)?.month ?? "1970-01";
	const months = summaries.map((item) => item.month);
	const [selected, setSelected] = (0, import_react.useState)(current);
	const s = summaries.find((x) => x.month === selected) ?? summaries.at(-1);
	const maxCollected = Math.max(1, ...summaries.map((item) => item.collected));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Community funds",
			title: "Contributions",
			description: "Monthly voluntary contributions for the whole community."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "-mx-4 mb-5 flex gap-2 overflow-x-auto px-4 pb-1 scrollbar-none",
			children: [...months].reverse().map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setSelected(m),
				className: cn("shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition-colors", m === selected ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:text-foreground"),
				children: formatMonth(m, "short")
			}, m))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "surface-hero p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.18em] text-gold",
					children: formatMonth(s.month)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-primary-foreground/80",
					children: "Total collected"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl font-semibold",
					children: formatINR(s.collected)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-primary-foreground/75",
					children: [
						s.entries,
						" manually recorded contribution",
						s.entries === 1 ? "" : "s"
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Total, {
				label: "Contribution entries",
				value: s.entries,
				currency: false
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Total, {
				label: "Average entry",
				value: s.entries ? Math.round(s.collected / s.entries) : 0
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Manual collection methods" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Method, {
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4" }),
				label: "UPI",
				value: s.upi
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Method, {
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "size-4" }),
				label: "Cash",
				value: s.cash
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Last 6 months" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "surface-card p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-40 items-end justify-between gap-3",
				children: summaries.map((m) => {
					const h = m.collected / maxCollected * 100;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setSelected(m.month),
						className: "flex h-full flex-1 flex-col items-center justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative w-full max-w-10 flex-1 overflow-hidden rounded-lg bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("absolute inset-x-0 bottom-0 rounded-lg transition-all", m.month === selected ? "bg-primary" : "bg-primary/35"),
								style: { height: `${h}%` }
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-[11px] font-semibold", m.month === selected ? "text-primary" : "text-muted-foreground"),
							children: formatMonth(m.month, "short").split(" ")[0]
						})]
					}, m.month);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex items-start gap-3 rounded-2xl bg-primary-soft p-4 text-sm text-accent-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Individual family payments are private. Only the admin can see who paid how much." })]
		})
	] });
}
function Total({ label, value, tone = "text-foreground", currency = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-1 font-display text-2xl font-semibold", tone),
			children: currency ? formatINR(value) : value
		})]
	});
}
function Method({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card flex items-center gap-3 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-10 place-items-center rounded-xl bg-gold-soft text-gold-foreground",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg font-semibold text-foreground",
			children: formatINR(value)
		})] })]
	});
}
//#endregion
export { ContributionsPage as component };

import { s as getPublicAnnouncements } from "./admin-api-CHwB38Wv.mjs";
import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/announcements-BMwvfvgu.js
var $$splitComponentImporter = () => import("./announcements-BSGhfIVM.mjs");
var Route = createFileRoute("/announcements")({
	loader: () => getPublicAnnouncements(),
	head: () => ({ meta: [
		{ title: "Announcements — Habshi Masjid Parivar" },
		{
			name: "description",
			content: "Notices, events and reminders from the Habshi Masjid committee in Jalore."
		},
		{
			property: "og:title",
			content: "Announcements — Habshi Masjid Parivar"
		},
		{
			property: "og:description",
			content: "Notices, events and reminders from Habshi Masjid, Jalore."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

import { t as APP_TIMEZONE } from "./date-0gm0zi69.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reminder-time-JjPPV1YP.js
function reminderTimeFromParts(parts) {
	const hour = Number(parts.hour);
	const minute = Number(parts.minute);
	if (!Number.isInteger(hour) || hour < 1 || hour > 12) throw new Error("Choose an hour from 1 to 12.");
	if (!Number.isInteger(minute) || minute < 0 || minute > 59) throw new Error("Choose a minute from 00 to 59.");
	if (parts.period !== "AM" && parts.period !== "PM") throw new Error("Choose AM or PM.");
	const hour24 = hour % 12 + (parts.period === "PM" ? 12 : 0);
	return `${String(hour24).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}
function reminderTimeToParts(time) {
	const match = time.match(/^(?:([01]\d|2[0-3])):([0-5]\d)$/);
	if (!match) throw new Error("Reminder time must be a valid 24-hour time.");
	const hour24 = Number(match[1]);
	return {
		hour: String(hour24 % 12 || 12),
		minute: match[2],
		period: hour24 < 12 ? "AM" : "PM"
	};
}
function formatReminderTime(time) {
	const parts = reminderTimeToParts(time);
	return `${parts.hour}:${parts.minute} ${parts.period}`;
}
function zonedClock(now, timeZone = APP_TIMEZONE) {
	const parts = new Intl.DateTimeFormat("en-CA", {
		timeZone,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23"
	}).formatToParts(now);
	const fields = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
	return {
		date: `${fields["year"]}-${fields["month"]}-${fields["day"]}`,
		time: `${fields["hour"]}:${fields["minute"]}`
	};
}
function reminderIsDue(now, reminderTime) {
	return zonedClock(now).time >= reminderTime;
}
//#endregion
export { zonedClock as a, reminderTimeToParts as i, reminderIsDue as n, reminderTimeFromParts as r, formatReminderTime as t };

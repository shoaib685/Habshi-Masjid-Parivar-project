import { i as __toESM } from "../_runtime.mjs";
import { i as formatDate, n as addDays } from "./date-0gm0zi69.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { c as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as PageHeader } from "./ui-B-mPjvYk.mjs";
import { t as DutyList } from "./DutyCards-D9C9fLdx.mjs";
import { t as Route } from "./schedule-wLG3rkTO.mjs";
import { i as TabsTrigger$1, n as TabsContent$1, r as TabsList$1, t as Tabs$1 } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schedule-D2oXD-CJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Tabs$1;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList$1, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = TabsList$1.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger$1, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = TabsTrigger$1.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent$1, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = TabsContent$1.displayName;
function groupByWeek(days) {
	const groups = [];
	for (const day of days) {
		const weekday = ((/* @__PURE__ */ new Date(`${day.date}T00:00:00Z`)).getUTCDay() + 6) % 7;
		const label = `Week of ${formatDate(addDays(day.date, -weekday), {
			day: "numeric",
			month: "short"
		})}`;
		const last = groups.at(-1);
		if (last && last.label === label) last.days.push(day);
		else groups.push({
			label,
			days: [day]
		});
	}
	return groups;
}
function SchedulePage() {
	const { today, schedule } = Route.useLoaderData();
	const [view, setView] = (0, import_react.useState)("upcoming");
	const days = view === "upcoming" ? schedule.filter((day) => day.date >= today).slice(0, 28) : schedule.filter((day) => day.date < today).slice(-28).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Rotation",
			title: "Duty schedule",
			description: "Next four weeks of food duty, in order."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: view,
			onValueChange: (v) => setView(v),
			className: "mb-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
				className: "grid h-11 w-full grid-cols-2 rounded-full bg-muted p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "upcoming",
					className: "rounded-full data-[state=active]:bg-card data-[state=active]:shadow-sm",
					children: "Upcoming"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "history",
					className: "rounded-full data-[state=active]:bg-card data-[state=active]:shadow-sm",
					children: "History"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-6",
			children: groupByWeek(days).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 px-1 font-sans text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground",
				children: g.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DutyList, {
				days: g.days,
				today
			})] }, g.label))
		})
	] });
}
//#endregion
export { SchedulePage as component };

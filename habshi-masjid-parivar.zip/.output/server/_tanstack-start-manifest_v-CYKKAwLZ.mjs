//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CYKKAwLZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/announcements",
			"/contributions",
			"/duty",
			"/schedule",
			"/settings",
			"/admin_/login"
		],
		preloads: [
			"/assets/index-D9MQ4N3i.js",
			"/assets/admin-api-DcPRG9VV.js",
			"/assets/react-dom-DMRjuTGV.js",
			"/assets/preload-helper-CGBf8cxm.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D9MQ4N3i.js"
		} }]
	},
	"/": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-4u4bJ8GY.js",
			"/assets/pin-DLYEwals.js",
			"/assets/date-DEq81QoK.js",
			"/assets/ui-DT-9oJcg.js",
			"/assets/DutyCards-CFCA3xux.js",
			"/assets/contributions-CLQ65AZd.js"
		]
	},
	"/admin": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CyWQjUEN.js",
			"/assets/useNavigate-C0dz33EK.js",
			"/assets/download-Cn4tOGJf.js",
			"/assets/map-pin-DlM7U0UQ.js",
			"/assets/date-DEq81QoK.js",
			"/assets/utils-DbguV03Q.js",
			"/assets/ui-DT-9oJcg.js",
			"/assets/DutyCards-CFCA3xux.js",
			"/assets/button-CfJWSVHW.js",
			"/assets/input-CXID7-ID.js",
			"/assets/contributions-CLQ65AZd.js"
		]
	},
	"/announcements": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/announcements.tsx",
		children: void 0,
		preloads: [
			"/assets/announcements-DEQ0wCym.js",
			"/assets/bell-ring-Cl0AiN5-.js",
			"/assets/info-ClhlMqz3.js",
			"/assets/pin-DLYEwals.js",
			"/assets/date-DEq81QoK.js",
			"/assets/ui-DT-9oJcg.js"
		]
	},
	"/contributions": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/contributions.tsx",
		children: void 0,
		preloads: [
			"/assets/contributions-BXcQyBAA.js",
			"/assets/smartphone-DHrpm_LU.js",
			"/assets/date-DEq81QoK.js",
			"/assets/utils-DbguV03Q.js",
			"/assets/ui-DT-9oJcg.js",
			"/assets/contributions-CLQ65AZd.js"
		]
	},
	"/duty": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/duty.tsx",
		children: void 0,
		preloads: [
			"/assets/duty-DS9YJoZ5.js",
			"/assets/ui-DT-9oJcg.js",
			"/assets/DutyCards-CFCA3xux.js"
		]
	},
	"/schedule": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/schedule.tsx",
		children: void 0,
		preloads: [
			"/assets/schedule-CALVvXCK.js",
			"/assets/date-DEq81QoK.js",
			"/assets/utils-DbguV03Q.js",
			"/assets/ui-DT-9oJcg.js",
			"/assets/DutyCards-CFCA3xux.js",
			"/assets/dist-BBMFlg7E.js"
		]
	},
	"/settings": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-PbwuR9sE.js",
			"/assets/download-Cn4tOGJf.js",
			"/assets/map-pin-DlM7U0UQ.js",
			"/assets/info-ClhlMqz3.js",
			"/assets/smartphone-DHrpm_LU.js",
			"/assets/ui-DT-9oJcg.js",
			"/assets/button-CfJWSVHW.js"
		]
	},
	"/admin_/login": {
		filePath: "F:/project/habshi-masjid-parivar/src/routes/admin_.login.tsx",
		children: void 0,
		preloads: [
			"/assets/admin_.login-Bk0kgJI7.js",
			"/assets/useNavigate-C0dz33EK.js",
			"/assets/button-CfJWSVHW.js",
			"/assets/input-CXID7-ID.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
